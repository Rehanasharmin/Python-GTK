#!/usr/bin/env bash
# Take a screenshot of the running Windows 10 GTK desktop.
# Usage: ./shoot.sh [output.png]
set -e
cd "$(dirname "$0")"

OUT="${1:-screenshots/shot-$(date +%Y%m%d-%H%M%S).png}"
mkdir -p "$(dirname "$OUT")"
DISPLAY_NUM="${DISPLAY_NUM:-99}"
export DISPLAY=":${DISPLAY_NUM}"

if ! xdpyinfo -display "$DISPLAY" >/dev/null 2>&1; then
  echo "[shoot.sh] No Xvfb running on $DISPLAY. Start it with ./start.sh first." >&2
  exit 1
fi

# Use ImageMagick `import` to capture the whole root window
import -window root "$OUT"
echo "[shoot.sh] Saved screenshot to $OUT ($(du -h "$OUT" | cut -f1))"
echo "$OUT"
