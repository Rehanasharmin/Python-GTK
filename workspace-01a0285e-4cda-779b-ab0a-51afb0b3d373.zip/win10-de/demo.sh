#!/usr/bin/env bash
# Record a guided-tour video of the Windows 10 GTK desktop.
# Drives the running desktop via its UDP control socket while ffmpeg captures X11.
#
# Usage: ./demo.sh [output.mp4] [duration_seconds]
set -e
cd "$(dirname "$0")"
export DISPLAY="${DISPLAY:-:99}"

OUT="${1:-video/demo-$(date +%Y%m%d-%H%M%S).mp4}"
DURATION="${2:-18}"
FPS="${FPS:-24}"
mkdir -p "$(dirname "$OUT")"

WIDTH="${WIN10_WIDTH:-1280}"
HEIGHT="${WIN10_HEIGHT:-800}"

# Start ffmpeg in the background
echo "[demo] Recording ${WIDTH}x${HEIGHT}@${FPS} for ${DURATION}s -> $OUT"
ffmpeg -hide_banner -loglevel warning -y \
  -f x11grab -video_size "${WIDTH}x${HEIGHT}" \
  -framerate "$FPS" -i "$DISPLAY" \
  -t "$DURATION" \
  -c:v libx264 -pix_fmt yuv420p -preset ultrafast -crf 20 \
  "$OUT" &
FFPID=$!

# Give ffmpeg a moment to start
sleep 1.5

# ---- Guided tour ----
C=./ctrl.sh
echo "[demo] Closing anything open..."
$C closeall >/dev/null 2>&1
sleep 1.0

echo "[demo] Opening Start menu..."
$C start >/dev/null 2>&1
sleep 1.5
$C start >/dev/null 2>&1   # close
sleep 0.6

echo "[demo] Opening File Explorer..."
$C open explorer >/dev/null 2>&1
sleep 1.5

echo "[demo] Opening Notepad..."
$C open notepad >/dev/null 2>&1
sleep 1.5

echo "[demo] Opening Calculator..."
$C open calc >/dev/null 2>&1
sleep 1.5

echo "[demo] Opening Command Prompt..."
$C open terminal >/dev/null 2>&1
sleep 2.0

echo "[demo] Opening Settings..."
$C open settings >/dev/null 2>&1
sleep 2.0

echo "[demo] Opening Start menu again..."
$C start >/dev/null 2>&1
sleep 1.8
$C start >/dev/null 2>&1
sleep 0.8

echo "[demo] Closing all windows..."
$C closeall >/dev/null 2>&1

# Wait for ffmpeg to finish its duration
wait "$FFPID"
echo "[demo] Saved: $OUT ($(du -h "$OUT" | cut -f1))"
echo "$OUT"
