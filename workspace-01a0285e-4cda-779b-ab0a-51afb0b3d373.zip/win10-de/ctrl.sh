#!/usr/bin/env bash
# Send a command to the running Windows 10 GTK desktop via its UDP control socket.
# Usage:
#   ./ctrl.sh open explorer|notepad|calc|settings|terminal|about
#   ./ctrl.sh close <app>
#   ./ctrl.sh start          (toggle start menu)
#   ./ctrl.sh closeall
#   ./ctrl.sh quit
set -e
PORT="${WIN10_PORT:-7890}"
MSG="$*"
if [ -z "$MSG" ]; then
  echo "usage: $0 <command> [arg]"; exit 1
fi
/usr/bin/python3 - "$MSG" "$PORT" <<'PYEOF'
import socket, sys
msg, port = sys.argv[1], int(sys.argv[2])
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.sendto(msg.encode("utf-8"), ("127.0.0.1", port))
print(f"sent: {msg}")
PYEOF
