#!/usr/bin/env python3
"""
Showcase driver — connects to the running desktop via X11 and walks it
through a sequence of states, capturing a screenshot of each.

Requires the desktop (./start.sh) and Xvfb running on DISPLAY :99.
Usage: DISPLAY=:99 ./showcase.py [output_dir]
"""
import os
import sys
import subprocess
import time
import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk, GLib

OUT = sys.argv[1] if len(sys.argv) > 1 else "screenshots/showcase"
os.makedirs(OUT, exist_ok=True)
DISPLAY = os.environ.get("DISPLAY", ":99")


def shoot(name):
    path = os.path.join(OUT, name)
    subprocess.run(["import", "-window", "root", path], check=True, env={**os.environ, "DISPLAY": DISPLAY})
    print(f"  shot -> {path}")
    return path


def xdotool(*args):
    subprocess.run(["xdotool", *args], check=True, env={**os.environ, "DISPLAY": DISPLAY})


def find_gtk_window():
    """Return the X11 window id of our desktop shell."""
    out = subprocess.check_output(["xdotool", "search", "--name", "Win10-DE"],
                                  env={**os.environ, "DISPLAY": DISPLAY}).decode().split()
    return out[0] if out else None


# The desktop is a single undecorated GTK window covering the screen.
# We drive it by synthesizing X events at known coordinates.
# Layout (1280x800):
#   Start button: around (18, 780)   (40px tall taskbar, 40px wide start)
#   Taskbar app buttons start at ~x=300
#   Desktop icons column: x=38, y = 50,136,222,308,394,480

COORDS = {
    "start":   (20, 780),
    "icon_pc": (40, 50),
    "icon_recycle": (40, 136),
    "icon_docs": (40, 222),
    "icon_notepad": (40, 308),
    "icon_calc": (40, 394),
    "icon_terminal": (40, 480),
    # start menu entries (menu opens at y=240..760, width 640)
    # sidebar power button is at x~24, near bottom of 520px menu -> y ~ 720
    "start_power": (24, 720),
    "start_settings_tile": (600, 500),  # settings tile bottom-right of tiles
}


def click(x, y, button=1):
    xdotool("mousemove", str(x), str(y))
    xdotool("click", str(button))
    time.sleep(0.6)


def double_click(x, y):
    xdotool("mousemove", str(x), str(y))
    xdotool("click", "--repeat", "2", "1")
    time.sleep(0.7)


def main():
    win = find_gtk_window()
    if not win:
        print("ERROR: desktop window 'Win10-DE' not found. Start ./start.sh first.", file=sys.stderr)
        sys.exit(1)
    xdotool("windowactivate", win)
    time.sleep(0.5)

    # 1. Current desktop with boot windows
    shoot("01-desktop.png")

    # 2. Close the front-most windows to get a cleaner desktop
    # Click the close button (X) of top window: titlebar X around x=620,y=80 for calc
    # We'll just repeatedly click the top-right X of the foremost window.
    for x, y in [(1100, 100), (1100, 100), (1100, 100)]:
        click(x, y)
        time.sleep(0.4)
    shoot("02-clean-desktop.png")

    # 3. Open the Start menu
    click(*COORDS["start"])
    time.sleep(0.4)
    shoot("03-start-menu.png")

    # 4. Click Settings tile in start menu
    click(600, 690)
    time.sleep(0.8)
    shoot("04-settings.png")

    # 5. Close settings, open calculator from start
    click(1100, 100)  # close
    time.sleep(0.4)
    click(*COORDS["start"])  # open start
    time.sleep(0.4)
    # click "Calculator" in app list (~ x 150, y ~ 320)
    click(180, 340)
    time.sleep(0.8)
    shoot("05-calculator.png")

    # 6. Open terminal from desktop
    double_click(*COORDS["icon_terminal"])
    time.sleep(0.8)
    shoot("06-terminal.png")

    # 7. Open notepad from desktop
    double_click(*COORDS["icon_notepad"])
    time.sleep(0.8)
    shoot("07-notepad.png")

    # 8. Open file explorer via start
    click(*COORDS["start"])
    time.sleep(0.3)
    click(180, 380)  # File Explorer in app list
    time.sleep(0.8)
    shoot("08-explorer.png")

    print("\nShowcase complete. Images in", OUT)


if __name__ == "__main__":
    main()
