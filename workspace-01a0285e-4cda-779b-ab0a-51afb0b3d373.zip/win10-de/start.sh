#!/usr/bin/env bash
# Start Xvfb virtual display + the Windows 10 GTK desktop.
set -e
cd "$(dirname "$0")"

WIDTH="${WIN10_WIDTH:-1280}"
HEIGHT="${WIN10_HEIGHT:-800}"
DEPTH=24
DISPLAY_NUM="${DISPLAY_NUM:-99}"
export DISPLAY=":${DISPLAY_NUM}"

# Start Xvfb if not already running on this display
if ! xdpyinfo -display "$DISPLAY" >/dev/null 2>&1; then
  echo "[win10-de] Starting Xvfb on ${DISPLAY} (${WIDTH}x${HEIGHT}x${DEPTH})..."
  Xvfb "$DISPLAY" -screen 0 "${WIDTH}x${HEIGHT}x${DEPTH}" -ac -nolisten tcp &
  XVFB_PID=$!
  echo "$XVFB_PID" > .xvfb.pid
  # wait for it
  for i in $(seq 1 30); do
    if xdpyinfo -display "$DISPLAY" >/dev/null 2>&1; then break; fi
    sleep 0.2
  done
fi

# Set a nice DPI / fonts
xrdb -merge <<< "Xft.dpi: 96" 2>/dev/null || true

echo "[win10-de] Launching desktop (use shoot.sh / record.sh to capture)..."
exec /usr/bin/python3 desktop.py
