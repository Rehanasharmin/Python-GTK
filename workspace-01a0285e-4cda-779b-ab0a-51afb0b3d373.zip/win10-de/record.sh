#!/usr/bin/env bash
# Record the desktop to an MP4 video using ffmpeg + X11grab.
# Usage: ./record.sh [output.mp4] [duration_seconds] [fps]
set -e
cd "$(dirname "$0")"

OUT="${1:-video/recording-$(date +%Y%m%d-%H%M%S).mp4}"
DURATION="${2:-10}"
FPS="${3:-24}"
mkdir -p "$(dirname "$OUT")"
DISPLAY_NUM="${DISPLAY_NUM:-99}"
export DISPLAY=":${DISPLAY_NUM}"

if ! xdpyinfo -display "$DISPLAY" >/dev/null 2>&1; then
  echo "[record.sh] No Xvfb running on $DISPLAY. Start it with ./start.sh first." >&2
  exit 1
fi

WIDTH="${WIN10_WIDTH:-1280}"
HEIGHT="${WIN10_HEIGHT:-800}"

echo "[record.sh] Recording ${WIDTH}x${HEIGHT}@${FPS}fps for ${DURATION}s -> $OUT"
ffmpeg -hide_banner -loglevel warning -y \
  -f x11grab -video_size "${WIDTH}x${HEIGHT}" \
  -framerate "$FPS" -i "$DISPLAY" \
  -t "$DURATION" \
  -c:v libx264 -pix_fmt yuv420p -preset ultrafast -crf 20 \
  "$OUT"
echo "[record.sh] Saved video to $OUT ($(du -h "$OUT" | cut -f1))"
echo "$OUT"
