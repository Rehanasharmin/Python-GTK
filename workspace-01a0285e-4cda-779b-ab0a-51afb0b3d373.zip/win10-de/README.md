# Windows 10 Desktop Environment — Python + GTK3

A fully graphical, interactive **Windows 10–style desktop** built with
**PyGObject / GTK3** (`gi` package) and rendered headlessly inside **Xvfb**.
It is designed so you can **take screenshots** today and **record videos**
tomorrow — programmatically, with no manual clicking.

---

## ✨ Features

- **Windows 10 look & feel**
  - Blue gradient wallpaper, desktop icons with labels
  - Dark taskbar with Start button, search box, running-app buttons,
    Wi‑Fi / volume / battery tray icons, and live clock/date
  - Vector-drawn Windows flag logo and tray icons (no external image assets)
  - Start menu with dark sidebar, app list, and colored live tiles
- **Draggable, overlapping windows** with minimize / maximize / close controls
- **Built-in apps**
  - 📁 File Explorer (sidebar, address bar, file grid, status bar)
  - 📝 Notepad (menu bar, editable text area, status bar)
  - 🧮 Calculator (fully functional — +, −, ×, ÷, %, ±, √, x²)
  - ⚙️ Settings (category navigation)
  - 🖥️ About Windows (system info)
  - ⌨️ Command Prompt (styled terminal)
- **Remote control socket** — drive the desktop from scripts (great for
  automated screenshots and videos)
- **Screenshot & video helpers** built on ImageMagick + ffmpeg/x11grab

---

## 📁 Files

| File | Purpose |
|------|---------|
| `desktop.py` | The GTK desktop environment (main application) |
| `style.css` | Windows 10 GTK/CSS theme |
| `start.sh` | Starts Xvfb + the desktop |
| `shoot.sh [file.png]` | Take a screenshot of the live desktop |
| `record.sh [file.mp4] [seconds] [fps]` | Record raw screen video |
| `demo.sh [file.mp4] [seconds]` | Record a **guided-tour** video (auto-opens apps) |
| `ctrl.sh <command>` | Send control commands to the running desktop |
| `showcase.py` | Automated multi-screenshot showcase driver |
| `screenshots/` | Saved screenshots |
| `video/` | Saved videos |

---

## 🚀 Quick start

### 1. Start the desktop
```bash
cd win10-de
./start.sh
```
This launches Xvfb on `:99` (1280×800, 24-bit) and runs `desktop.py`.

Override resolution:
```bash
WIN10_WIDTH=1920 WIN10_HEIGHT=1080 ./start.sh
```

Start clean (no auto-opened windows):
```bash
WIN10_AUTOOPEN= ./start.sh
```

### 2. Take a screenshot
```bash
./shoot.sh screenshots/hello.png
```
(Pass no argument to auto-name it with a timestamp.)

### 3. Record a video
Raw recording (you drive the desktop meanwhile):
```bash
./record.sh video/clip.mp4 15      # 15 seconds at 24 fps
```

Or let the script drive a guided tour automatically:
```bash
./demo.sh video/tour.mp4 20
```

---

## 🎛️ Remote control

The desktop listens on **UDP `127.0.0.1:7890`** for one-line text commands.
This is how videos/screenshots are automated without a mouse.

```bash
./ctrl.sh open explorer     # open File Explorer
./ctrl.sh open notepad      # open Notepad
./ctrl.sh open calc         # open Calculator
./ctrl.sh open settings     # open Settings
./ctrl.sh open terminal     # open Command Prompt
./ctrl.sh open about        # open About Windows

./ctrl.sh close calc        # close a specific app
./ctrl.sh closeall          # close every window
./ctrl.sh start             # toggle Start menu
./ctrl.sh quit              # exit the desktop
```

You can also send commands from any language over UDP:
```python
import socket
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.sendto(b"open calc", ("127.0.0.1", 7890))
```

Change the port with `WIN10_PORT=...`.

---

## 🧮 Tips for making videos

1. Start clean: `WIN10_AUTOOPEN= ./start.sh`
2. In one terminal, run `./demo.sh video/title.mp4 18`
   — it opens Start, Explorer, Notepad, Calculator, Terminal, Settings,
   then Start again, all timed for a smooth sequence.
3. For a custom sequence, copy `demo.sh` and edit the `ctrl.sh` lines and
   `sleep` durations. Each `open`/`start`/`closeall` is one UDP command,
   so you can choreograph anything frame-by-frame.
4. To add cursor movement / typing animation in future, combine `ctrl.sh`
   with `xdotool` (already installed) for synthetic mouse/keyboard events.

---

## 🔧 Requirements (already installed in this environment)

- `python3-gi`, `gir1.2-gtk-3.0`, `gir1.2-gdkpixbuf-2.0`, `gir1.2-pango-1.0`
- `python3-cairo` (for icon rendering)
- `xvfb`, `imagemagick` (`import`), `ffmpeg`, `xdotool`
- Fonts: `fonts-noto-color-emoji` (for emoji glyphs) + DejaVu Sans

---

## 🧩 How it works

- `desktop.py` creates one undecorated `Gtk.Window` sized to the screen.
- Inside it, `Gtk.Fixed` layers hold the desktop icons, app windows,
  taskbar, and Start menu.
- Each app window is a `Gtk.Box` wrapped in an `EventBox` so it can be
  dragged by its titlebar and raised/focused.
- Icons are drawn at runtime with **Cairo** (rounded squares + glyphs)
  and converted to `GdkPixbuf`, so there are no binary assets to ship.
- A `GLib.io_add_watch` on a non-blocking UDP socket receives commands
  on the GTK main loop — no threading required.
- Xvfb provides a real X11 framebuffer, so standard tools (`import`,
  `ffmpeg -f x11grab`, `xdotool`) see a genuine screen to capture.
