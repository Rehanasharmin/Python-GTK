# Agent Guide — `win10env`

This document is written for **AI agents and automation scripts** that need
to launch the Windows 10-style desktop, operate it, and capture screenshots
or screen recordings. It is the authoritative technical reference; pair it
with [`readme.md`](readme.md) for the high-level overview.

---

## 0. Mental model

```
                ┌──────────────────────────────────────────────┐
                │  Xvfb  (virtual X display, e.g. :99)         │
                │  ┌────────────────────────────────────────┐  │
   UDP :7899 ──▶│  │  desktop.py  (GTK3 "Windows 10")       │  │
   commands     │  │  • wallpaper, desktop icons             │  │
                │  │  • draggable app windows                │  │
                │  │  • taskbar + Start menu                 │  │
                │  │  • visible software cursor (Cairo)      │  │
                │  └────────────────────────────────────────┘  │
                └───────────────────────┬──────────────────────┘
                                        │ x11grab / import
                          ┌─────────────┴──────────────┐
                          │  ffmpeg (MP4) / import (PNG)│
                          └────────────────────────────┘
```

There are **two cursors** to understand:

1. The **real X pointer** inside Xvfb (invisible) — this is what
   `xdotool` moves/clicks with. Clicks land wherever it is.
2. The **visible software cursor** drawn by `desktop.py` — this is what
   shows up in screenshots and video.

The high-level API keeps them in sync: `move_cursor()`/`set_cursor()` move
both, and `click()` uses xdotool at the same coordinates. You generally do
not need to think about this — just use the API.

---

## 1. Install (once per machine)

```bash
./install.sh          # detects apt/dnf/yum/pacman/zypper/apk
bin/win10 doctor      # prints the status of each dependency
```

If `doctor` reports anything `MISSING`, re-run `install.sh` or install the
equivalent package for your distro manually.

The Python package (`win10env/`) has **no pip dependencies** beyond the
system-provided `gi` (PyGObject) and `cairo`. It is imported by adding
the repo root to `sys.path`; the `bin/win10` launcher does this for you.

---

## 2. Lifecycle

### CLI

```bash
win10 start [--width W] [--height H] [--display N] [--port P]
            [--auto-open LIST] [--log FILE]
win10 stop
```

- `start` launches **Xvfb** then **desktop.py**, writes state to
  `~/.win10env.json`, and returns once the desktop is ready (a `.ready`
  file appears in the repo). It does **not** block; the desktop keeps
  running in the background.
- `--display N` / `--port P` are optional; free ones are auto-picked.
- `--auto-open ''` starts with no windows open (good for clean recordings).
  The default is `explorer,notepad,calc`.
- `stop` terminates `desktop.py` and the Xvfb it started.

State file (`~/.win10env.json`) records `pid`, `display`, `port`,
`width`, `height` so subsequent `win10` commands attach automatically.

### Python

```python
from win10env import Win10

# Context manager: starts on enter, stops on exit
with Win10(width=1280, height=800, auto_open="") as d:
    d.screenshot("out.png")

# Or manual
d = Win10(width=1280, height=800)
d.start()
...
d.stop()
```

Useful constructor args: `width`, `height`, `display` (int, e.g. `99`),
`port` (UDP), `auto_open` (string or `None`/`""`), `log_file`, `python`
(path to a Python that can `import gi`).

---

## 3. The CLI

Run `win10 <command> --help` for the authoritative flags. Summary:

| Command | Purpose |
|---|---|
| `win10 doctor` | check dependencies |
| `win10 start` | launch desktop |
| `win10 stop` | stop desktop |
| `win10 open <app>` | open an app |
| `win10 close <app>` | close an app |
| `win10 closeall` | close every window |
| `win10 menu` | toggle Start menu |
| `win10 cursor X Y` | instantly position visible cursor |
| `win10 click [X Y] [--button left\|middle\|right]` | click |
| `win10 type TEXT [--wpm N] [--interval S]` | type text |
| `win10 KEYSYM` | press a named key |
| `win10 screenshot OUT.png` | capture PNG |
| `win10 record OUT.mp4 [--duration S] [--fps N] [--script FILE]` | record MP4 |
| `win10 run PLAN.json` | run an action plan without recording |

Apps: `explorer`, `notepad`, `calc`, `settings`, `about`, `terminal`.

---

## 4. The Python API (`Win10`)

### 4.1 Apps & windows

```python
d.open_app("notepad")      # opens (or focuses) an app window
d.close_app("notepad")
d.close_all()
d.start_menu()             # toggle Start menu
```

### 4.2 Cursor & input

```python
d.show_cursor()
d.hide_cursor()
d.set_cursor(x, y)                       # instant jump (visible + real X)
d.move_cursor(x, y, seconds=0.4)         # animated, ease-out
d.click(button="left", x=None, y=None, seconds=0.25)
d.double_click(x, y, seconds=0.3)
d.right_click(x=None, y=None)
d.type_text("Hello", wpm=80)             # per-char via xdotool (realistic)
d.type_text("instant")                   # wpm=0 → instant insertion
d.press_key("Return")                    # also "BackSpace", "ctrl+a", ...
d.sleep(1.0)
```

`click()` without coordinates clicks wherever the cursor currently is;
with `x,y` it animates there first then clicks.

### 4.3 Named coordinates

For common UI elements (so you don't hardcode pixels), use `coord()`:

```python
x, y = d.coord("start")            # Start button
x, y = d.coord("icon_notepad")     # Notepad desktop icon
x, y = d.coord("clock")            # clock in tray
# also: search, task_apps, tray, icon_pc, icon_recycle, icon_docs,
#        icon_calc, icon_terminal, start_calc, start_explorer, ...
```

Coordinates are in the **1280×800 reference space** and are automatically
scaled to the running resolution.

### 4.4 Capture

```python
d.screenshot("screenshots/shot.png")

d.record("video/clip.mp4", duration=10, fps=24)

d.record("video/tour.mp4", actions=[
    {"action": "open_app", "app": "notepad"},
    {"action": "move_cursor", "x": 300, "y": 200, "seconds": 0.5},
    {"action": "click"},
    {"action": "type", "text": "Hello", "wpm": 80},
    {"action": "sleep", "seconds": 1.0},
], fps=24, crf=20, preset="ultrafast")
```

If both `actions` and `duration` are omitted, it records 5 seconds. When
`actions` is given and `duration` is not, the duration is estimated from
the plan (with startup/teardown padding).

`run_actions(actions)` executes a plan **without** recording — handy for
setting up a scene before a separately-controlled capture.

---

## 5. Action reference (JSON plans)

Every action is a JSON object with an `"action"` key.

### App / window control

```json
{"action": "open_app", "app": "notepad"}
{"action": "close_app", "app": "notepad"}
{"action": "close_all"}
{"action": "start_menu"}
```

`app` ∈ `explorer | notepad | calc | settings | about | terminal`.

### Cursor

```json
{"action": "show_cursor"}
{"action": "hide_cursor"}
{"action": "set_cursor", "x": 640, "y": 400}
{"action": "move_cursor", "x": 640, "y": 400, "seconds": 0.5}
```

### Mouse

```json
{"action": "click", "button": "left"}
{"action": "click", "x": 100, "y": 100, "button": "left", "seconds": 0.25}
{"action": "double_click", "x": 40, "y": 325}
{"action": "right_click", "x": 40, "y": 325}
{"action": "coord_click", "name": "start", "button": "left"}
```

`button` ∈ `left | middle | right` (default `left`). When `x,y` are given,
the cursor animates there first. `coord_click` uses a named coordinate.

### Keyboard

```json
{"action": "type", "text": "Hello, world!", "wpm": 80}
{"action": "type", "text": "instant text"}
{"action": "press_key", "key": "Return"}
```

- `wpm` derives an inter-keystroke delay from words-per-minute
  (5 chars/word). Omit it (or set 0) for instant insertion via the
  in-process `type` command.
- `key` is an xdotool keysym: `Return`, `BackSpace`, `Tab`, `Escape`,
  `ctrl+a`, `ctrl+s`, `alt+F4`, `shift+LEFT`, etc.
- To type a newline inside `text`, use a real `\n` in the JSON string
  (`"line1\nline2"`).

### Flow / capture

```json
{"action": "sleep", "seconds": 1.2}
{"action": "screenshot", "path": "screenshots/scene.png"}
```

---

## 6. Coordinate system & resolution

- The desktop's origin `(0,0)` is the **top-left**; y increases downward.
- The taskbar occupies the bottom 40 px; keep windows/cursor above
  `height - 40` unless intentionally clicking the taskbar.
- Reference layout is **1280×800**. If you start at another size,
  `Win10.coord()` scales named points for you. For raw `x,y` in actions,
  use the actual pixel coordinates of the running resolution.
- The visible cursor's hotspot is its **top-left** tip (the arrow tip),
  same as Windows. So `click(x, y)` clicks exactly at `(x, y)`.

### Useful reference points (1280×800)

| Element | x | y |
|---|---:|---:|
| Start button | 22 | 780 |
| Search box | ~150 | 780 |
| Taskbar app buttons | from ~300 | 780 |
| Tray (wifi/vol/batt) | ~1240 | 780 |
| Clock | ~1140 | 780 |
| Desktop icon rows (This PC, Recycle, Documents, Notepad, Calc, Terminal) | 40 | 55, 145, 235, 325, 415, 505 |

For the **Notepad** window at its default 600×440 position (cascaded from
80,50), the editable text area is roughly `x:90–580`, `y:110–410`.

---

## 7. The UDP control socket (advanced)

`desktop.py` listens on `udp://127.0.0.1:<WIN10_PORT>` (default 7890,
written to `.ready` on boot). Send a single UTF-8 line per command:

```
open <app>
close <app>
focus <app>
closeall
start
cursor <x> <y>
cursor_show
cursor_hide
type <text>
key <keysym>
quit
```

Example:

```bash
echo "open notepad" | nc -u -w1 127.0.0.1 7890
# or
python3 -c "import socket;s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);s.sendto(b'cursor 300 200',('127.0.0.1',7890))"
```

Notes:

- `type <text>` inserts at the focused widget's cursor (in-process). It is
  instant; for realistic per-character typing use the CLI/Python `type`
  with `--wpm`, which routes through `xdotool`.
- The socket is fire-and-forget (no ack). After sending a state-changing
  command, wait ~0.3–0.8 s for GTK to lay out the new window before
  capturing.

---

## 8. Recording recipes

### A. Simple 10-second clip after setting up a scene

```python
with Win10(auto_open="") as d:
    d.open_app("explorer")
    d.sleep(1.0)
    d.record("video/explorer.mp4", duration=10)
```

### B. Fully choreographed video (recommended)

```python
plan = [
    {"action": "start_menu"},
    {"action": "sleep", "seconds": 1.0},
    {"action": "open_app", "app": "explorer"},
    {"action": "move_cursor", "x": 400, "y": 300, "seconds": 0.6},
    {"action": "click"},
    {"action": "sleep", "seconds": 0.8},
    {"action": "open_app", "app": "notepad"},
    {"action": "move_cursor", "x": 300, "y": 180, "seconds": 0.5},
    {"action": "click"},
    {"action": "type", "text": "This was recorded automatically.", "wpm": 70},
    {"action": "sleep", "seconds": 1.5},
]
with Win10(auto_open="") as d:
    d.record("video/tour.mp4", actions=plan, fps=24)
```

### C. Multiple takes / parallel instances

```python
a = Win10(display=101, port=7901); a.start()
b = Win10(display=102, port=7902); b.start()
a.record("v1.mp4", actions=plan1)
b.record("v2.mp4", actions=plan2)
a.stop(); b.stop()
```

Each `Win10()` without explicit display/port auto-selects a free one, so
you can run many in parallel.

### D. CLI-driven

```bash
win10 start --auto-open ''
win10 record video/tour.mp4 --script examples/plan_tour.json --fps 24
win10 stop
```

---

## 9. Writing good action plans

1. **Start clean**: launch with `--auto-open ''` and begin plans with
   `{"action": "close_all"}` + a short sleep.
2. **Add breathing room**: insert `sleep` actions (0.5–1.5 s) after
   opening windows, opening the Start menu, and typing — this is what
   makes footage look natural.
3. **Animate the cursor**: prefer `move_cursor` with `seconds` over
   `set_cursor`. Use `seconds` between 0.25 (snappy) and 0.7 (leisurely).
4. **Click AFTER moving**: each `click`/`double_click` with `x,y` moves
   first, so you don't need a separate `move_cursor` unless you want the
   movement shown as its own beat.
5. **Type at realistic speed**: `wpm` of 50–90 looks human; instant typing
   looks robotic. For long text, split into multiple `type` actions with
   short pauses.
6. **Show the cursor**: it is shown by default at startup. If you hid it,
   re-`show_cursor` before recording.
7. **Resolution**: 1280×800 is compact and fast; use 1920×1080 for
   "full HD" output (set `--width 1920 --height 1080`). ffmpeg encodes at
   the exact screen size.
8. **Stability**: after `open_app`, wait ~0.6–1.2 s before interacting;
   GTK must realize and lay out the new window.

---

## 10. Troubleshooting

### `win10 start` says "desktop did not become ready in time"
- Check the log (`--log /tmp/win10.log`). Common causes:
  - Missing `gi`/`cairo` for the chosen Python → run `bin/win10 doctor`.
  - Display number already in use → pass a different `--display N`.
- The `.ready` file in the repo directory appears once the control socket
  is bound; you can poll for it.

### Clicks don't land where the visible cursor is
- Always move via `move_cursor`/`set_cursor`/`click(x,y)` (these sync the
  real X pointer). If you used a raw xdotool command, also send a `cursor
  X Y` control command so the visible cursor follows.

### Screenshot is all black / blank
- Ensure Xvfb is running (`xdpyinfo -display :99`).
- Wait ~1 s after `start` before the first capture.
- Make sure you capture `-window root` (the helpers do this).

### Video has no cursor
- Use the software cursor (shown by default). The `record` method passes
  `-draw_mouse 0` to ffmpeg so ffmpeg doesn't try to draw the (invisible)
  X cursor on top of ours. If you want ffmpeg's cursor instead, call
  `record(..., draw_mouse=True)`.

### `xdotool` hangs / times out
- Don't pass `--sync` on Xvfb (the API doesn't). Use plain `mousemove`.
- Ensure only one process owns the display.

### Typing inserts text in the wrong place
- `type_text`/`type` types into whatever has X focus. Click the target
  first (e.g., Notepad's text area) and add a short sleep. To replace all
  text, press `ctrl+a` then `BackSpace` before typing.

### Multiple desktops interfere
- Always pass distinct `--display` and `--port` (or let the Python API
  auto-allocate). Never run two Xvfbs on the same display number.

### `pkill -f desktop.py` killed my shell
- In bash, don't `pkill -f` a pattern that matches your own command line.
  Use the CLI's `win10 stop`, or `pkill -x python3` cautiously, or kill
  the PID stored in `~/.win10env.json`.

---

## 11. Worked example: end-to-end MP4 from a fresh agent turn

```python
import sys, os
sys.path.insert(0, "/home/user/win10-de")
from win10env import Win10

plan = [
    {"action": "close_all"},
    {"action": "sleep", "seconds": 0.6},
    {"action": "start_menu"},
    {"action": "sleep", "seconds": 1.2},
    {"action": "start_menu"},
    {"action": "sleep", "seconds": 0.4},
    {"action": "open_app", "app": "notepad"},
    {"action": "move_cursor", "x": 300, "y": 180, "seconds": 0.5},
    {"action": "click"},
    {"action": "press_key", "key": "ctrl+a"},
    {"action": "press_key", "key": "BackSpace"},
    {"action": "type", "text": "Hello from an AI agent.\n", "wpm": 80},
    {"action": "type", "text": "This Windows 10 desktop is 100% scripted.\n", "wpm": 70},
    {"action": "sleep", "seconds": 1.0},
    {"action": "open_app", "app": "calc"},
    {"action": "move_cursor", "x": 200, "y": 350, "seconds": 0.5},
    {"action": "click"},
    {"action": "sleep", "seconds": 1.5},
]

with Win10(width=1280, height=800, auto_open="") as d:
    out = d.record("video/agent-demo.mp4", actions=plan, fps=24)
    print("Saved:", out, os.path.getsize(out), "bytes")
```

Run it:

```bash
cd /home/user/win10-de
python3 examples/make_demo.py     # (save the snippet there)
```

The result is a self-contained H.264 MP4 showing a cursor moving, the
Start menu opening, Notepad being typed into, and Calculator launching —
exactly the kind of "legit screen recording" the project is for.

---

## 12. Extending

- **Add an app**: write a `build_<name>(shell)` function in `desktop.py`
  that returns a `Gtk.Widget`, register it in the `APPS` dict, and it's
  instantly reachable via `open <name>` and `open_app("<name>")`.
- **Add actions**: extend `DesktopShell._on_control` (socket verbs) and
  `Win10.run_actions` / `bin/win10` (API/CLI actions).
- **Change the look**: edit `style.css` and/or the icon factory in
  `desktop.py`.
- **Higher fidelity**: increase resolution, add more apps, or animate
  tiles / notifications.
