#!/usr/bin/env bash
# record.sh [output.mp4] [duration_seconds] [fps] — record the screen.
set -e
cd "$(dirname "$0")"
OUT="${1:-video/recording-$(date +%Y%m%d-%H%M%S).mp4}"
DUR="${2:-10}"
FPS="${3:-24}"
exec ./bin/win10 record "$OUT" --duration "$DUR" --fps "$FPS"
