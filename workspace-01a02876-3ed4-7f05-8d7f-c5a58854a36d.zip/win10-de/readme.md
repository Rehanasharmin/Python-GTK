# win10env — A scriptable Windows 10 desktop for AI agents & screen recording

`win10env` runs a **fully graphical, interactive Windows 10–style desktop**
on any Linux machine — including headless servers and sandboxes — and lets
an AI agent (or a script) **drive it and record legitimate-looking
MP4 screen videos / PNG screenshots**.

It is written in **Python with GTK3 (the `gi` / PyGObject package)**,
renders into a virtual display (**Xvfb**), draws its own visible mouse
cursor, and accepts commands over a UDP control socket and a
high-level Python/CLI API.

> **Goal:** give an AI agent a self-contained "screen recording studio"
> that it can launch, operate (open apps, move the cursor, click, type,
> drag windows), and record — no human, no real display, no cloud.

---

## Why this exists

Screen recordings of an operating system are useful for demos, tutorials,
marketing clips, and synthetic training data — but automating a *real*
Windows VM from an agent is heavy, flaky, and slow. This project gives
you:

- a convincing **Windows 10 look** (wallpaper, desktop icons, taskbar,
  Start menu with live tiles, draggable overlapping windows);
- a set of **working apps** (File Explorer, Notepad, Calculator,
  Settings, About, Command Prompt);
- a **visible, animated cursor** so recordings look human-operated;
- **deterministic, scriptable control** from Python or the shell;
- **one-command MP4 recording** via ffmpeg/x11grab;
- everything running **headless** on Linux via Xvfb.

---

## Features at a glance

| Capability | How |
|---|---|
| Windows 10 desktop | GTK3 + CSS, 1280×800 (configurable) |
| Headless rendering | Xvfb virtual framebuffer |
| Visible mouse cursor | In-window Cairo-drawn arrow, animated via API |
| Apps | Explorer, Notepad, Calculator (functional), Settings, About, Terminal |
| Windows | Draggable titlebars; minimize / maximize / close; z-order; cascade |
| Start menu | App list + colored live tiles + power button |
| Taskbar | Start btn, search, running-app buttons, tray (wifi/volume/battery), clock |
| Open/close apps | UDP control socket + Python/CLI |
| Move & animate cursor | `move_cursor(x,y,seconds)` with easing |
| Click / double-click / right-click | xdotool under the hood |
| Type text | Per-character at a realistic WPM, or instant |
| Press keys | Enter, BackSpace, ctrl+a, etc. |
| Screenshots | `import` (ImageMagick) → PNG |
| Video recording | `ffmpeg -f x11grab` → H.264 MP4 |
| Action plans | JSON list of actions executed while recording |
| Multiple desktops | Run several isolated instances on different displays/ports |

---

## Requirements

- Linux (Debian/Ubuntu, Fedora/RHEL, Arch, openSUSE, Alpine)
- X11 userland (Xvfb); no physical display needed
- ~250 MB of packages
- Python 3.9+ (uses the **system** Python that has PyGObject)

The exact packages are installed by `install.sh` (apt/dnf/yum/pacman/zypper/apk):
`python3-gi python3-gi-cairo python3-cairo gir1.2-gtk-3.0
gir1.2-gdkpixbuf-2.0 gir1.2-pango-1.0 gir1.2-glib-2.0 xvfb imagemagick
ffmpeg xdotool x11-utils fonts-noto-color-emoji fonts-symbola`

---

## Install

```bash
git clone <this-repo> win10env   # or copy the folder
cd win10env
./install.sh                     # detects your distro, installs packages
bin/win10 doctor                 # verify everything is present
```

`install.sh` also symlinks the CLI to `~/.local/bin/win10`.

---

## Quick start (shell)

```bash
# 1. Launch (starts Xvfb + the desktop, returns immediately)
win10 start                       # 1280x800, auto-picks free display/port

# 2. Drive it
win10 open notepad                # open Notepad
win10 cursor 300 200              # move the visible cursor
win10 click                       # click at the cursor
win10 type "Hello, world!" --wpm 80
win10 menu                        # open Start menu
win10 open calc                   # open Calculator

# 3. Capture
win10 screenshot desktop.png
win10 record clip.mp4 --duration 8

# 4. Tear down
win10 stop
```

---

## Quick start (Python)

```python
from win10env import Win10

with Win10(width=1280, height=800) as desktop:
    desktop.screenshot("screenshots/01-empty.png")

    desktop.open_app("notepad")
    desktop.move_cursor(300, 180, seconds=0.5)
    desktop.click()
    desktop.type_text("Recorded by an AI agent.\n", wpm=90)

    desktop.record("video/demo.mp4", duration=10)
```

---

## Record a scripted, "human-operated" video

Pass a JSON **action plan** — the agent's choreography — and the desktop
runs the actions while ffmpeg records:

```bash
win10 record video/tour.mp4 --script examples/plan_tour.json
```

Or from Python:

```python
desktop.record("video/tour.mp4", [
    {"action": "start_menu"},
    {"action": "sleep", "seconds": 1.0},
    {"action": "open_app", "app": "explorer"},
    {"action": "move_cursor", "x": 500, "y": 350, "seconds": 0.6},
    {"action": "click"},
    {"action": "sleep", "seconds": 1.0},
    {"action": "open_app", "app": "notepad"},
    {"action": "move_cursor", "x": 320, "y": 200, "seconds": 0.5},
    {"action": "click"},
    {"action": "type", "text": "Hello from a scripted agent!", "wpm": 80},
    {"action": "sleep", "seconds": 1.5},
])
```

Every action moves the **visible cursor**, so the video genuinely looks
like someone is operating the PC.

---

## Project layout

```
win10-de/
├── desktop.py          # the GTK3 Windows 10 desktop (apps, windows, cursor)
├── style.css           # Windows 10 GTK/CSS theme
├── install.sh          # distro-agnostic provisioning
├── bin/win10           # the agent-facing CLI
├── win10env/           # the agent-facing Python package
│   ├── __init__.py
│   └── core.py         # Win10 class: launch, drive, capture, record
├── examples/           # example JSON action plans
├── start.sh            # thin wrapper: `win10 start`
├── shoot.sh            # thin wrapper: `win10 screenshot`
├── record.sh           # thin wrapper: `win10 record --duration`
├── readme.md           # this file
├── guides.md           # DETAILED agent guide (API, actions, recipes, troubleshooting)
├── screenshots/        # output PNGs
└── video/              # output MP4s
```

---

## Documentation

- **[guides.md](guides.md)** — the comprehensive guide for AI agents:
  the full CLI, the `Win10` Python API, every action type, coordinate
  system, recording recipes, parallel instances, troubleshooting, and
  a worked end-to-end video example.

- **`bin/win10 --help`** / **`win10 <command> --help`** — CLI reference.

---

## License / note

This is an independent re-creation of the Windows 10 *visual style* for
automation/recording purposes. It is not affiliated with or endorsed by
Microsoft. All trademarks belong to their owners.
