#!/usr/bin/env bash
# install.sh — provision everything needed to run the Windows 10 GTK desktop
# on any Linux machine. Detects the distro / package manager and installs
# system packages, then verifies the Python GTK stack.
set -e
cd "$(dirname "$0")"

SUDO=""
if [ "$(id -u)" -ne 0 ]; then
  if command -v sudo >/dev/null 2>&1; then SUDO="sudo"; fi
fi

# ------------- detect package manager -------------
PM=""
INSTALL=""
PKGS=""
if command -v apt-get >/dev/null 2>&1; then
  PM="apt"
  INSTALL="apt-get install -y"
  PKGS="python3-gi python3-gi-cairo python3-cairo gir1.2-gtk-3.0 gir1.2-gdkpixbuf-2.0 gir1.2-pango-1.0 gir1.2-glib-2.0 xvfb imagemagick ffmpeg xdotool x11-utils fonts-noto-color-emoji fonts-symbola"
elif command -v dnf >/dev/null 2>&1; then
  PM="dnf"
  INSTALL="dnf install -y"
  PKGS="python3-gobject python3-cairo gtk3 gdk-pixbuf2 pango xvfb ImageMagick ffmpeg xdotool xorg-x11-utils google-noto-color-emoji-fonts"
elif command -v yum >/dev/null 2>&1; then
  PM="yum"; INSTALL="yum install -y"
  PKGS="python3-gobject python3-cairo gtk3 gdk-pixbuf2 pango xvfb ImageMagick ffmpeg xdotool xorg-x11-utils google-noto-color-emoji-fonts"
elif command -v pacman >/dev/null 2>&1; then
  PM="pacman"
  INSTALL="pacman -S --noconfirm --needed"
  PKGS="python-gobject cairo gtk3 gdk-pixbuf2 pango xvfb imagemagick ffmpeg xdotool xorg-xdpyinfo noto-fonts-emoji"
elif command -v zypper >/dev/null 2>&1; then
  PM="zypper"; INSTALL="zypper install -y"
  PKGS="python3-gobject python3-cairo gtk3 gdk-pixbuf-loader pango xvfb ImageMagick ffmpeg xdotool xdpyinfo noto-coloremoji-fonts"
elif command -v apk >/dev/null 2>&1; then
  PM="apk"; INSTALL="apk add --no-cache"
  PKGS="py3-gobject py3-gobject3 py3-cairo gtk+3.0 gdk-pixbuf pango xvfb imagemagick ffmpeg xdotool xdpyinfo noto-fonts-emoji"
else
  echo "ERROR: unsupported distro. Please install equivalents of:" >&2
  echo "  python3-gi, python3-cairo, gtk3 gir bindings, xvfb, imagemagick," >&2
  echo "  ffmpeg, xdotool, x11-utils, and a color-emoji font." >&2
  exit 1
fi

echo "[install] Detected package manager: $PM"
if [ -n "$SUDO" ]; then echo "[install] Using sudo."; fi
$SUDO $INSTALL $PKGS

# ------------- symlink the CLI into ~/.local/bin -------------
BIN_DIR="$HOME/.local/bin"
mkdir -p "$BIN_DIR"
ln -sf "$(pwd)/bin/win10" "$BIN_DIR/win10"
chmod +x bin/win10 desktop.py *.sh 2>/dev/null || true
echo "[install] Linked CLI to $BIN_DIR/win10"
case ":$PATH:" in
  *":$BIN_DIR:"*) ;;
  *) echo "[install] NOTE: $BIN_DIR is not on your PATH. Add it:"
     echo "           echo 'export PATH=\"\$HOME/.local/bin:\$PATH\"' >> ~/.bashrc" ;;
esac

# ------------- verify -------------
echo "[install] Verifying..."
./bin/win10 doctor
echo "[install] Done. Try:  win10 start && win10 screenshot desktop.png"
