"""
Core agent-operable API for the Windows 10 GTK desktop environment.

This module is pure-Python and only depends on the standard library plus
the external tools (Xvfb, ffmpeg, import/imagemagick, xdotool) that the
bootstrap script installs. It does NOT import `gi` itself — the GTK
desktop runs as a separate process (`desktop.py`).
"""
from __future__ import annotations

import os
import re
import time
import shutil
import socket
import shlex
import subprocess
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
DESKTOP_PY = HERE / "desktop.py"
READY_FILE = HERE / ".ready"

# Apps supported by desktop.py
APPS = ("explorer", "notepad", "calc", "settings", "about", "terminal")

DEPS = {
    "Xvfb": "xvfb",
    "import": "imagemagick",
    "ffmpeg": "ffmpeg",
    "xdotool": "xdotool",
}


class Win10Error(RuntimeError):
    pass


def _which(name):
    return shutil.which(name)


def check_dependencies():
    """Return a dict of {binary: path_or_None} for required external tools."""
    found = {name: _which(name) for name in DEPS}
    # python that can import gi + cairo
    py = _find_gtk_python()
    found["python3-gi"] = py
    return found


def _find_gtk_python():
    """Find a python interpreter that can `import gi` and `import cairo`."""
    candidates = []
    env_py = os.environ.get("WIN10_PYTHON")
    if env_py:
        candidates.append(env_py)
    candidates += ["/usr/bin/python3", shutil.which("python3")]
    for py in candidates:
        if not py or not os.path.exists(py):
            continue
        try:
            r = subprocess.run(
                [py, "-c", "import gi, cairo; gi.require_version('Gtk','3.0')"],
                capture_output=True, timeout=10,
            )
            if r.returncode == 0:
                return py
        except Exception:
            continue
    return None


def find_free_display():
    """Pick a free X display number by scanning /tmp/.X*-lock."""
    for n in range(99, 200):
        lock = Path(f"/tmp/.X{n}-lock")
        if not lock.exists():
            return n
    raise Win10Error("No free X display found between :99 and :199")


class Win10:
    """Handle to a running Windows 10-style desktop.

    Use as a context manager, or call .start() / .stop() manually.
    """

    def __init__(self, width=1280, height=800, depth=24,
                 display=None, port=None, auto_open=None,
                 log_file=None, python=None):
        self.width = int(width)
        self.height = int(height)
        self.depth = int(depth)
        self.display_num = display if display is not None else find_free_display()
        self.display = f":{self.display_num}"
        self.port = int(port) if port else self._free_port()
        self.auto_open = auto_open  # comma string or None
        self.python = python or _find_gtk_python()
        self.log_file = log_file
        self._xvfb = None
        self._desktop = None
        self._log_fh = None
        self._win_id = None

    # ---- lifecycle ----
    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *exc):
        self.stop()

    def start(self):
        if self._desktop is not None:
            return self
        if not self.python:
            raise Win10Error(
                "No Python with gi/cairo found. Run ./install.sh to install "
                "python3-gi, python3-cairo, and the GTK gir bindings."
            )
        self._start_xvfb()
        self._start_desktop()
        self._wait_ready()
        # Hide the real X11 cursor inside our screen so it doesn't double up
        # with the software cursor. (Best-effort.)
        self._hide_real_cursor()
        return self

    def stop(self):
        if self._desktop:
            self._send("quit")
            try:
                self._desktop.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._desktop.kill()
            self._desktop = None
        if self._xvfb:
            try:
                self._xvfb.terminate()
                self._xvfb.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._xvfb.kill()
            self._xvfb = None
        if self._log_fh:
            self._log_fh.close()
            self._log_fh = None
        try:
            READY_FILE.unlink()
        except FileNotFoundError:
            pass

    # ---- process management ----
    def _start_xvfb(self):
        env = dict(os.environ)
        self._xvfb = subprocess.Popen(
            ["Xvfb", self.display, "-screen", "0",
             f"{self.width}x{self.height}x{self.depth}",
             "-ac", "-nolisten", "tcp", "+extension", "RANDR"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, env=env,
        )
        # wait for the X server
        for _ in range(50):
            r = subprocess.run(["xdpyinfo", "-display", self.display],
                               capture_output=True)
            if r.returncode == 0:
                return
            time.sleep(0.1)
        raise Win10Error(f"Xvfb on {self.display} did not become ready")

    def _start_desktop(self):
        env = dict(os.environ)
        env["DISPLAY"] = self.display
        env["WIN10_WIDTH"] = str(self.width)
        env["WIN10_HEIGHT"] = str(self.height)
        env["WIN10_PORT"] = str(self.port)
        if self.auto_open is not None:
            env["WIN10_AUTOOPEN"] = self.auto_open
        if self.log_file:
            self._log_fh = open(self.log_file, "w")
            out = self._log_fh
        else:
            out = subprocess.DEVNULL
        self._desktop = subprocess.Popen(
            [self.python, str(DESKTOP_PY)],
            cwd=str(HERE), env=env, stdout=out, stderr=subprocess.STDOUT,
        )

    def _wait_ready(self, timeout=20):
        deadline = time.time() + timeout
        while time.time() < deadline:
            if self._desktop and self._desktop.poll() is not None:
                raise Win10Error(
                    f"desktop.py exited early with code {self._desktop.returncode}. "
                    f"Check the log: {self.log_file or '(stderr discarded)'}"
                )
            if READY_FILE.exists():
                return True
            time.sleep(0.1)
        raise Win10Error("desktop did not become ready in time")

    def _hide_real_cursor(self):
        """Best-effort: make the X11 root cursor invisible.

        We already draw a software cursor; an extra X cursor would look
        doubled. This uses xset/xdotool if available and silently ignores
        failures.
        """
        env = dict(os.environ, DISPLAY=self.display)
        # Move the real pointer far off the visible screen
        try:
            subprocess.run(
                ["xdotool", "mousemove", str(self.width + 100),
                 str(self.height + 100)],
                env=env, capture_output=True, timeout=5,
            )
        except Exception:
            pass

    # ---- control channel ----
    @staticmethod
    def _free_port():
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]
        s.close()
        return port

    def _send(self, cmd):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(2.0)
        s.sendto(cmd.encode("utf-8"), ("127.0.0.1", self.port))
        s.close()

    def _xdotool(self, *args):
        env = dict(os.environ, DISPLAY=self.display)
        return subprocess.run(["xdotool", *args], env=env,
                              capture_output=True, text=True, timeout=10)

    def _desktop_window(self):
        """Return the X11 window id of the desktop, caching it."""
        if self._win_id:
            return self._win_id
        r = self._xdotool("search", "--name", "Win10-DE")
        for line in r.stdout.split():
            if line.strip().isdigit():
                self._win_id = line.strip()
                return self._win_id
        # fallback: first non-root window
        r = self._xdotool("search", "--onlyvisible", "--class", "")
        for line in r.stdout.split():
            if line.strip().isdigit():
                self._win_id = line.strip()
                return self._win_id
        return None

    def _raise_desktop(self):
        wid = self._desktop_window()
        if wid:
            self._xdotool("windowraise", wid)

    # ---- high-level actions ----
    def open_app(self, app):
        if app not in APPS:
            raise Win10Error(f"unknown app {app!r}; choose from {APPS}")
        self._send(f"open {app}")
        self._pump(0.6)

    def close_app(self, app):
        if app not in APPS:
            raise Win10Error(f"unknown app {app!r}")
        self._send(f"close {app}")
        self._pump(0.4)

    def close_all(self):
        self._send("closeall")
        self._pump(0.4)

    def start_menu(self):
        self._send("start")
        self._pump(0.4)

    def show_cursor(self):
        self._send("cursor_show")
        self._pump(0.1)

    def hide_cursor(self):
        self._send("cursor_hide")
        self._pump(0.1)

    def move_cursor(self, x, y, seconds=0.4):
        """Animate the visible cursor from its current position to (x,y)."""
        x = max(0, min(self.width - 1, int(x)))
        y = max(0, min(self.height - 1, int(y)))
        cur = getattr(self, "_cur", (self.width // 2, self.height // 2))
        steps = max(2, int(float(seconds) / 0.02))
        for i in range(1, steps + 1):
            t = i / steps
            # ease-out
            e = 1 - (1 - t) * (1 - t)
            ix = int(cur[0] + (x - cur[0]) * e)
            iy = int(cur[1] + (y - cur[1]) * e)
            self._send(f"cursor {ix} {iy}")
            time.sleep(0.02)
        self._cur = (x, y)
        # also move the real X pointer to the same spot so xdotool clicks land
        self._xdotool("mousemove", str(x), str(y))
        self._pump(0.05)

    def set_cursor(self, x, y):
        """Instantly position the cursor (no animation)."""
        self._send(f"cursor {int(x)} {int(y)}")
        self._cur = (int(x), int(y))
        self._xdotool("mousemove", str(int(x)), str(int(y)))
        self._pump(0.05)

    def click(self, button="left", x=None, y=None, seconds=0.25):
        """Click at (x,y), or at the current cursor position if not given.

        Also moves the visible cursor there first.
        """
        if x is not None and y is not None:
            self.move_cursor(x, y, seconds=max(0.1, seconds - 0.1))
        self._raise_desktop()
        btn = {"left": "1", "middle": "2", "right": "3"}.get(button, "1")
        self._xdotool("click", btn)
        self._pump(0.2)

    def double_click(self, x, y, seconds=0.3):
        self.move_cursor(x, y, seconds=max(0.1, seconds - 0.1))
        self._raise_desktop()
        self._xdotool("click", "--repeat", "2", "--delay", "120", "1")
        self._pump(0.3)

    def right_click(self, x=None, y=None):
        self.click(button="right", x=x, y=y)

    def type_text(self, text, wpm=0, interval=None):
        """Type text into the currently focused widget.

        If interval is set, type character-by-character with that delay
        (seconds). If wpm > 0, derive an interval from words-per-minute
        (assuming 5 chars/word). Otherwise insert instantaneously via
        the in-process `type` command.
        """
        if interval or wpm:
            if wpm and not interval:
                # chars per second = wpm * 5 / 60
                cps = max(1.0, wpm * 5 / 60.0)
                interval = 1.0 / cps
            delay_ms = str(int(interval * 1000))
            env = dict(os.environ, DISPLAY=self.display)
            # Type line-by-line so embedded newlines become real Return presses.
            for i, line in enumerate(text.split("\n")):
                if i > 0:
                    self._xdotool("key", "Return")
                    self._pump(interval)
                if line:
                    with tempfile.NamedTemporaryFile("w", delete=False, suffix=".txt") as f:
                        f.write(line)
                        tmp = f.name
                    try:
                        self._xdotool("type", "--file", tmp, "--delay", delay_ms)
                    finally:
                        os.unlink(tmp)
            self._pump(0.1)
        else:
            # instant insertion (no per-char realism)
            self._send("type " + text.replace("\n", "\\n"))
            self._pump(0.1)

    def press_key(self, keysym):
        """Press a named key, e.g. 'Return', 'BackSpace', 'ctrl+a'."""
        self._xdotool("key", keysym)
        self._pump(0.1)

    def sleep(self, seconds):
        self._pump(float(seconds))

    # ---- coordinates of on-screen elements (1280x800 layout) ----
    # These scale with the configured resolution so you can use them in
    # scripts without hardcoding pixels.
    def _scale(self, fx, fy):
        return int(fx * self.width / 1280), int(fy * self.height / 800)

    def coord(self, name):
        """Return (x, y) for a named UI element, scaled to resolution."""
        # Layout in 1280x800 reference coordinates
        ref = {
            "start":       (22, 780),
            "search":      (150, 780),
            "task_apps":   (360, 780),
            "tray":        (1230, 780),
            "clock":       (1130, 780),
            "icon_pc":     (40, 55),
            "icon_recycle":(40, 145),
            "icon_docs":   (40, 235),
            "icon_notepad":(40, 325),
            "icon_calc":   (40, 415),
            "icon_terminal":(40, 505),
            # Start-menu relative (menu opens 640x520 at bottom-left)
            "start_calc":     (180, 360),
            "start_explorer": (180, 410),
            "start_notepad":  (180, 460),
            "start_terminal": (180, 390),
            "start_settings_tile": (600, 700),
            "start_power":   (24, 720),
        }
        if name not in ref:
            raise Win10Error(f"unknown coordinate {name!r}; known: {sorted(ref)}")
        return self._scale(*ref[name])

    # ---- capture ----
    def screenshot(self, path):
        path = str(path)
        os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
        env = dict(os.environ, DISPLAY=self.display)
        # -window root captures the whole virtual screen
        r = subprocess.run(
            ["import", "-window", "root", path],
            env=env, capture_output=True, text=True, timeout=30,
        )
        if r.returncode != 0:
            raise Win10Error(f"screenshot failed: {r.stderr.strip()}")
        return path

    def record(self, output, actions=None, duration=None, fps=24,
               crf=20, preset="ultrafast", draw_mouse=False):
        """Record an MP4. Either pass `duration` seconds of raw recording,
        or a list of `actions` to execute while recording.

        Actions are dicts:
            {"action": "open_app", "app": "notepad"}
            {"action": "close_app", "app": "notepad"}
            {"action": "close_all"}
            {"action": "start_menu"}
            {"action": "move_cursor", "x": 640, "y": 400, "seconds": 0.4}
            {"action": "set_cursor", "x": 10, "y": 10}
            {"action": "click", "x": 100, "y": 100, "button": "left"}
            {"action": "double_click", "x": 40, "y": 325}
            {"action": "right_click", "x": 40, "y": 325}
            {"action": "type", "text": "hi", "wpm": 60}
            {"action": "press_key", "key": "Return"}
            {"action": "screenshot", "path": "shot.png"}
            {"action": "sleep", "seconds": 1.0}
            {"action": "show_cursor"}
            {"action": "hide_cursor"}
        """
        output = str(output)
        os.makedirs(os.path.dirname(os.path.abspath(output)) or ".", exist_ok=True)
        env = dict(os.environ, DISPLAY=self.display)

        if actions is None and duration is None:
            duration = 5

        # Compute total duration if actions are given (estimate)
        if actions is not None and duration is None:
            duration = self._estimate_duration(actions)

        cmd = [
            "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
            "-f", "x11grab",
            "-video_size", f"{self.width}x{self.height}",
            "-framerate", str(fps),
        ]
        # -draw_mouse is an INPUT option, so it MUST appear before -i.
        # We draw our own software cursor, so tell ffmpeg not to draw X's.
        if not draw_mouse:
            cmd += ["-draw_mouse", "0"]
        cmd += [
            "-i", self.display,
            "-t", str(duration),
            "-c:v", "libx264", "-pix_fmt", "yuv420p",
            "-preset", preset, "-crf", str(crf), output,
        ]

        ffmpeg = subprocess.Popen(cmd, env=env, stdout=subprocess.PIPE,
                                  stderr=subprocess.STDOUT)
        try:
            time.sleep(1.0)  # let ffmpeg start grabbing
            if actions:
                self.run_actions(actions)
            else:
                time.sleep(float(duration))
            ffmpeg.wait(timeout=duration + 30)
        finally:
            if ffmpeg.poll() is None:
                ffmpeg.terminate()
                try:
                    ffmpeg.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    ffmpeg.kill()
        if ffmpeg.returncode not in (0, 255):
            out = ffmpeg.stdout.read().decode("utf-8", "replace") if ffmpeg.stdout else ""
            raise Win10Error(f"ffmpeg failed ({ffmpeg.returncode}): {out}")
        return output

    @staticmethod
    def _estimate_duration(actions):
        total = 1.5  # startup
        for a in actions:
            act = a.get("action")
            if act == "sleep":
                total += float(a.get("seconds", 0.5))
            elif act == "move_cursor":
                total += float(a.get("seconds", 0.4)) + 0.1
            elif act in ("click", "double_click", "right_click"):
                total += 0.3
            elif act == "type":
                t = a.get("text", "")
                wpm = a.get("wpm", 0)
                if wpm:
                    total += max(0.3, len(t) / max(1.0, wpm * 5 / 60.0))
                else:
                    total += 0.2
            elif act == "open_app":
                total += 0.8
            else:
                total += 0.3
        return total + 1.0

    def run_actions(self, actions):
        """Execute a list of action dicts (same schema as record())."""
        for a in actions:
            act = a.get("action")
            if act == "open_app":
                self.open_app(a["app"])
            elif act == "close_app":
                self.close_app(a["app"])
            elif act == "close_all":
                self.close_all()
            elif act == "start_menu":
                self.start_menu()
            elif act == "move_cursor":
                self.move_cursor(a["x"], a["y"], seconds=a.get("seconds", 0.4))
            elif act == "set_cursor":
                self.set_cursor(a["x"], a["y"])
            elif act == "click":
                self.click(button=a.get("button", "left"),
                           x=a.get("x"), y=a.get("y"),
                           seconds=a.get("seconds", 0.25))
            elif act == "double_click":
                self.double_click(a["x"], a["y"], seconds=a.get("seconds", 0.3))
            elif act == "right_click":
                self.right_click(x=a.get("x"), y=a.get("y"))
            elif act == "type":
                self.type_text(a["text"], wpm=a.get("wpm", 0),
                               interval=a.get("interval"))
            elif act == "press_key":
                self.press_key(a["key"])
            elif act == "screenshot":
                self.screenshot(a["path"])
            elif act == "sleep":
                self.sleep(a.get("seconds", 0.5))
            elif act == "show_cursor":
                self.show_cursor()
            elif act == "hide_cursor":
                self.hide_cursor()
            elif act == "coord_click":
                x, y = self.coord(a["name"])
                self.click(button=a.get("button", "left"), x=x, y=y)
            else:
                raise Win10Error(f"unknown action: {act!r}")

    @staticmethod
    def _pump(seconds=0.1):
        """Let the GTK main loop process pending events, then wait."""
        end = time.time() + float(seconds)
        # We can't run the other process's loop, but a short sleep gives
        # it CPU time. GTK idle handlers run on their own.
        time.sleep(max(0.0, end - time.time()))
