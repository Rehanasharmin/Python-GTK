"""
win10env — agent-operable Windows 10-style screen recording environment.

A small library + CLI that lets any AI agent (or human script) launch a
headless Windows 10-style desktop, drive it with high-level actions
(open apps, move the mouse, click, type, drag windows), and record
legitimate-looking MP4 screen recordings.

Typical usage:

    from win10env import Win10

    with Win10(width=1280, height=800) as desktop:
        desktop.screenshot("desktop.png")
        desktop.open_app("notepad")
        desktop.type("Hello, world!")
        desktop.record("demo.mp4", [
            {"action": "start_menu"},
            {"action": "sleep", "seconds": 1},
            {"action": "open_app", "app": "explorer"},
            {"action": "move_cursor", "x": 640, "y": 400, "seconds": 0.6},
            {"action": "click"},
            {"action": "sleep", "seconds": 1},
        ])
"""
from .core import Win10, Win10Error, check_dependencies

__all__ = ["Win10", "Win10Error", "check_dependencies"]
__version__ = "1.0.0"
