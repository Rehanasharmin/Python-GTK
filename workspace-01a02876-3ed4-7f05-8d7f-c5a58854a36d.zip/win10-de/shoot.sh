#!/usr/bin/env bash
# shoot.sh [output.png] — take a screenshot of the running desktop.
set -e
cd "$(dirname "$0")"
OUT="${1:-screenshots/shot-$(date +%Y%m%d-%H%M%S).png}"
exec ./bin/win10 screenshot "$OUT"
