#!/usr/bin/env python3
"""
End-to-end demo: launch a clean Windows 10 desktop and record a scripted,
human-looking MP4. Run from the repo root:

    python3 examples/make_demo.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from win10env import Win10  # noqa: E402

PLAN = [
    {"action": "close_all"},
    {"action": "sleep", "seconds": 0.6},
    {"action": "start_menu"},
    {"action": "sleep", "seconds": 1.2},
    {"action": "start_menu"},
    {"action": "sleep", "seconds": 0.4},
    {"action": "open_app", "app": "notepad"},
    {"action": "move_cursor", "x": 300, "y": 180, "seconds": 0.5},
    {"action": "click"},
    {"action": "press_key", "key": "ctrl+a"},
    {"action": "press_key", "key": "BackSpace"},
    {"action": "type", "text": "Hello from an AI agent.\n", "wpm": 80},
    {"action": "type", "text": "This Windows 10 desktop is 100% scripted.\n", "wpm": 70},
    {"action": "sleep", "seconds": 1.0},
    {"action": "open_app", "app": "calc"},
    {"action": "move_cursor", "x": 200, "y": 350, "seconds": 0.5},
    {"action": "click"},
    {"action": "sleep", "seconds": 1.5},
]


def main():
    out = sys.argv[1] if len(sys.argv) > 1 else "video/agent-demo.mp4"
    with Win10(width=1280, height=800, auto_open="") as d:
        path = d.record(out, actions=PLAN, fps=24)
    print(f"Saved {path} ({os.path.getsize(path)} bytes)")


if __name__ == "__main__":
    main()
