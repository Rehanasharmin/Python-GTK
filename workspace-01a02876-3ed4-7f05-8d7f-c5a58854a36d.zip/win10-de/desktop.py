#!/usr/bin/env python3
"""
Windows 10-style Desktop Environment built with PyGObject (GTK3).

Runs inside Xvfb for headless rendering. Screenshot / record with:
  ./shoot.sh screenshot.png
  ./record.sh video.mp4 10
"""
import os
import sys
import socket
import datetime
import cairo

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("GdkPixbuf", "2.0")
gi.require_version("Pango", "1.0")
from gi.repository import Gtk, Gdk, GdkPixbuf, Pango, GLib, GObject

# ------------------------------------------------------------------
# Settings
# ------------------------------------------------------------------
SCREEN_W = int(os.environ.get("WIN10_WIDTH", "1280"))
SCREEN_H = int(os.environ.get("WIN10_HEIGHT", "800"))
CSS_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "style.css")

# Colors
COLOR_TASKBAR_BG = Gdk.RGBA()
COLOR_TASKBAR_BG.parse("rgba(20,30,45,0.96)")
COLOR_WIN_BG = Gdk.RGBA()
COLOR_WIN_BG.parse("#f0f0f0")
COLOR_TITLE = Gdk.RGBA()
COLOR_TITLE.parse("#ffffff")
COLOR_SEL = Gdk.RGBA()
COLOR_SEL.parse("#cce8ff")


def load_css():
    """Load the CSS theme."""
    provider = Gtk.CssProvider()
    provider.load_from_path(CSS_PATH)
    screen = Gdk.Screen.get_default()
    Gtk.StyleContext.add_provider_for_screen(
        screen, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
    )


# ------------------------------------------------------------------
# Simple icon factory – produces small Cairo-rendered pixbuf icons
# ------------------------------------------------------------------
def _hex_to_rgba(color):
    c = Gdk.RGBA()
    c.parse(color)
    return (int(c.red * 255), int(c.green * 255), int(c.blue * 255), int(c.alpha * 255))


def make_icon(symbol, bg_color, size=48, fg_color=(1, 1, 1)):
    """Draw a rounded square with a unicode symbol, return GdkPixbuf."""
    surface = cairo.ImageSurface(cairo.FORMAT_ARGB32, size, size)
    ctx = cairo.Context(surface)
    # Rounded-rect background
    radius = size * 0.18
    ctx.new_sub_path()
    ctx.arc(size - radius, radius, radius, -0.5 * 3.14159, 0)
    ctx.arc(size - radius, size - radius, radius, 0, 0.5 * 3.14159)
    ctx.arc(radius, size - radius, radius, 0.5 * 3.14159, 3.14159)
    ctx.arc(radius, radius, radius, 3.14159, 1.5 * 3.14159)
    ctx.close_path()
    if isinstance(bg_color, str):
        c = Gdk.RGBA()
        c.parse(bg_color)
        ctx.set_source_rgba(c.red, c.green, c.blue, c.alpha)
    else:
        ctx.set_source_rgba(*bg_color)
    ctx.fill()
    # Symbol (only draw glyphs that are single-character ascii; emoji may lack color but renders as glyph)
    if isinstance(fg_color, str):
        fr, fg, fb, fa = _hex_to_rgba(fg_color)
        ctx.set_source_rgba(fr / 255, fg / 255, fb / 255, fa / 255)
    else:
        ctx.set_source_rgba(*fg_color)
    ctx.select_font_face("DejaVu Sans", cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
    ctx.set_font_size(size * 0.52)
    xb, yb, w, h, xa, ya = ctx.text_extents(symbol)
    ctx.move_to((size - w) / 2 - xb, (size + h) / 2)
    ctx.show_text(symbol)
    surface.flush()

    # Convert cairo ARGB32 (native-endian, premultiplied) -> GdkPixbuf RGBA.
    # On little-endian, cairo bytes are B,G,R,A. We swap to R,G,B,A and unpremultiply.
    data = surface.get_data()
    stride = surface.get_stride()
    out = bytearray(size * size * 4)
    for row in range(size):
        s = row * stride
        d = row * size * 4
        for col in range(size):
            b, g, r, a = data[s], data[s + 1], data[s + 2], data[s + 3]
            if a:
                # unpremultiply
                r = min(255, (r * 255 + a // 2) // a)
                g = min(255, (g * 255 + a // 2) // a)
                b = min(255, (b * 255 + a // 2) // a)
            out[d] = r
            out[d + 1] = g
            out[d + 2] = b
            out[d + 3] = a
            s += 4
            d += 4
    return GdkPixbuf.Pixbuf.new_from_bytes(
        GLib.Bytes.new(bytes(out)),
        GdkPixbuf.Colorspace.RGB, True, 8,
        size, size, size * 4
    )


def _new_pixbuf(size):
    return GdkPixbuf.Pixbuf.new(GdkPixbuf.Colorspace.RGB, True, 8, size, size)


def make_wifi_icon(size=18, color=(0.9, 0.93, 0.96)):
    s = size
    surface = cairo.ImageSurface(cairo.FORMAT_ARGB32, s, s)
    ctx = cairo.Context(surface)
    ctx.set_source_rgba(*color)
    # Three arcs
    cx, cy = s * 0.5, s * 0.78
    ctx.set_line_width(max(1.0, s * 0.08))
    ctx.set_line_cap(cairo.LINE_CAP_ROUND)
    for i, r in enumerate((s * 0.62, s * 0.42, s * 0.22)):
        ctx.new_sub_path()
        ctx.arc(cx, cy, r, 3.14159, 2 * 3.14159)
        ctx.stroke()
    # dot
    ctx.arc(cx, cy, s * 0.05, 0, 2 * 3.14159)
    ctx.fill()
    return _surface_to_pixbuf(surface, s)


def make_volume_icon(size=18, color=(0.9, 0.93, 0.96)):
    s = size
    surface = cairo.ImageSurface(cairo.FORMAT_ARGB32, s, s)
    ctx = cairo.Context(surface)
    ctx.set_source_rgba(*color)
    # speaker body
    ctx.move_to(s * 0.06, s * 0.38)
    ctx.line_to(s * 0.32, s * 0.38)
    ctx.line_to(s * 0.56, s * 0.16)
    ctx.line_to(s * 0.56, s * 0.84)
    ctx.line_to(s * 0.32, s * 0.62)
    ctx.line_to(s * 0.06, s * 0.62)
    ctx.close_path()
    ctx.fill()
    # sound waves
    ctx.set_line_width(max(1.0, s * 0.07))
    ctx.set_line_cap(cairo.LINE_CAP_ROUND)
    ctx.arc(s * 0.58, s * 0.5, s * 0.18, -0.7, 0.7)
    ctx.stroke()
    ctx.arc(s * 0.58, s * 0.5, s * 0.32, -0.6, 0.6)
    ctx.stroke()
    return _surface_to_pixbuf(surface, s)


def make_battery_icon(size=18, color=(0.9, 0.93, 0.96)):
    s = size
    surface = cairo.ImageSurface(cairo.FORMAT_ARGB32, s, s)
    ctx = cairo.Context(surface)
    ctx.set_source_rgba(*color)
    # outline
    l, t, r, b = s * 0.06, s * 0.30, s * 0.82, s * 0.70
    ctx.set_line_width(max(1.0, s * 0.07))
    ctx.rectangle(l, t, r - l, b - t)
    ctx.stroke()
    # nub
    nub = s * 0.10
    ctx.rectangle(r, s * 0.38, nub, s * 0.24)
    ctx.fill()
    # fill
    ctx.rectangle(l + s * 0.05, t + s * 0.05, (r - l) * 0.75, b - t - s * 0.10)
    ctx.fill()
    return _surface_to_pixbuf(surface, s)


def make_logo_icon(size=22, color=(0.3, 0.76, 1.0)):
    """Windows flag logo (4 panes)."""
    s = size
    surface = cairo.ImageSurface(cairo.FORMAT_ARGB32, s, s)
    ctx = cairo.Context(surface)
    gap = s * 0.06
    half = (s - gap * 3) / 2
    panes = [
        (gap, gap),
        (gap * 2 + half, gap),
        (gap, gap * 2 + half),
        (gap * 2 + half, gap * 2 + half),
    ]
    for x, y in panes:
        ctx.rectangle(x, y, half, half)
    ctx.set_source_rgba(*color)
    ctx.fill()
    return _surface_to_pixbuf(surface, s)


def _surface_to_pixbuf(surface, size):
    surface.flush()
    data = surface.get_data()
    stride = surface.get_stride()
    out = bytearray(size * size * 4)
    for row in range(size):
        s = row * stride
        d = row * size * 4
        for col in range(size):
            b, g, r, a = data[s], data[s + 1], data[s + 2], data[s + 3]
            if a:
                r = min(255, (r * 255 + a // 2) // a)
                g = min(255, (g * 255 + a // 2) // a)
                b = min(255, (b * 255 + a // 2) // a)
            out[d] = r
            out[d + 1] = g
            out[d + 2] = b
            out[d + 3] = a
            s += 4
            d += 4
    return GdkPixbuf.Pixbuf.new_from_bytes(
        GLib.Bytes.new(bytes(out)),
        GdkPixbuf.Colorspace.RGB, True, 8,
        size, size, size * 4
    )


# Pre-built icons
ICONS = {
    "pc":       make_icon("🖥", "#0078d7", 48),
    "recycle":  make_icon("♻", "#107c10", 48),
    "folder":   make_icon("📁", "#ca5010", 48),
    "edge":     make_icon("e", "#0078d7", 48),
    "notepad":  make_icon("📄", "#3c4550", 48),
    "calc":     make_icon("🧮", "#0078d7", 48),
    "settings": make_icon("⚙", "#3c4550", 48),
    "store":    make_icon("🛍", "#6b2c91", 48),
    "photos":   make_icon("🖼", "#b12e2e", 48),
    "mail":     make_icon("✉", "#0078d7", 48),
    "music":    make_icon("♫", "#ca5010", 48),
    "video":    make_icon("▶", "#b12e2e", 48),
    "paint":    make_icon("🎨", "#6b2c91", 48),
    "terminal": make_icon(">_", "#0c0c0c", 48, (0.1, 0.9, 0.2)),
    "word":     make_icon("W", "#107c10", 48),
    "excel":    make_icon("X", "#107c10", 48),
    "power":    make_icon("⏻", "#3c4550", 24),
    "user":     make_icon("👤", "#0078d7", 24),
    "search":   make_icon("🔍", "#ffffff", 16),
    "wifi":     make_wifi_icon(18),
    "volume":   make_volume_icon(18),
    "battery":  make_battery_icon(18),
    "logo":     make_logo_icon(22),
}


# ------------------------------------------------------------------
# Software cursor overlay (always visible in screenshots / video)
# ------------------------------------------------------------------
class CursorLayer(Gtk.DrawingArea):
    """A full-screen transparent overlay that draws a Windows-style arrow.

    Drawn INSIDE the main desktop window so alpha-blending works even on
    Xvfb (which has no compositing manager). Added as the *last* child of
    the desktop's fixed container, so it paints on top of windows, the
    taskbar, and the Start menu. Clicks pass through because DrawingArea
    only covers its own small damaged region and we don't connect input
    events here.
    """

    SIZE = 24

    def __init__(self, width, height):
        super().__init__()
        self.set_size_request(width, height)
        self.set_app_paintable(True)
        self.connect("draw", self._on_draw)
        self._visible = False
        self._x = width // 2
        self._y = height // 2

    def mov_co(self, x, y):
        old = (self._x, self._y)
        self._x = int(x)
        self._y = int(y)
        r = self.SIZE + 2
        self.queue_draw_area(old[0] - 1, old[1] - 1, r, r)
        self.queue_draw_area(self._x - 1, self._y - 1, r, r)

    def show_cur(self, show=True):
        changed = bool(show) != self._visible
        self._visible = bool(show)
        if changed:
            self.queue_draw()

    def is_shown(self):
        return self._visible

    def _on_draw(self, _widget, cr):
        if not self._visible:
            return False
        cr.save()
        cr.translate(self._x, self._y)
        # Classic Windows arrow pointer — black outline, white fill
        cr.set_line_width(1.4)
        cr.set_line_join(cairo.LINE_JOIN_ROUND)
        cr.set_line_cap(cairo.LINE_CAP_ROUND)
        cr.move_to(2, 1)
        cr.line_to(2, 17)
        cr.line_to(6.5, 13.5)
        cr.line_to(9, 20)
        cr.line_to(11.5, 19)
        cr.line_to(9, 13)
        cr.line_to(15, 13)
        cr.close_path()
        cr.set_source_rgb(0, 0, 0)
        cr.stroke_preserve()
        cr.set_source_rgb(1, 1, 1)
        cr.fill()
        cr.restore()
        return False


# ------------------------------------------------------------------
# Draggable / resizable window frame
# ------------------------------------------------------------------
class AppWindow(Gtk.Box):
    """A draggable, closable window rendered inside the desktop."""

    def __init__(self, title, icon_key, content, w=640, h=440, parent_shell=None):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.shell = parent_shell
        self.app_id = icon_key
        self.set_size_request(w, h)
        self.set_app_paintable(False)

        ctx = self.get_style_context()
        ctx.add_class("app-window")

        self.titlebar = self._build_titlebar(title, icon_key)
        self.pack_start(self.titlebar, False, False, 0)
        self.pack_start(content, True, True, 0)

        # State
        self._drag = None
        self.z = 0

        # Event box so the whole window receives clicks for focus
        self._eb = Gtk.EventBox()
        self._eb.add(self)
        self._eb.connect("button-press-event", self._on_focus)

    def get_eventbox(self):
        return self._eb

    def _build_titlebar(self, title, icon_key):
        tb = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        tb_ctx = tb.get_style_context()
        tb_ctx.add_class("titlebar")
        tb.set_size_request(-1, 30)

        # drag handle covers the title area
        self._drag_handle = Gtk.EventBox()
        self._drag_handle.add(tb)
        self._drag_handle.connect("button-press-event", self._on_title_press)
        self._drag_handle.connect("motion-notify-event", self._on_title_motion)
        self._drag_handle.connect("button-release-event", self._on_title_release)

        # Icon
        img = Gtk.Image.new_from_pixbuf(ICONS[icon_key].scale_simple(16, 16, GdkPixbuf.InterpType.BILINEAR))
        img.set_margin_start(8)
        tb.pack_start(img, False, False, 0)

        lbl = Gtk.Label(label=title)
        lbl.get_style_context().add_class("titlebar-label")
        lbl.set_xalign(0)
        lbl.set_margin_start(6)
        tb.pack_start(lbl, True, True, 0)

        def make_btn(symbol, cls, handler):
            b = Gtk.Button(label=symbol)
            b.get_style_context().add_class("title-btn")
            if cls:
                b.get_style_context().add_class(cls)
            b.set_relief(Gtk.ReliefStyle.NONE)
            b.set_focus_on_click(False)
            b.connect("clicked", handler)
            return b

        self.btn_min = make_btn("—", "", lambda *_: self.minimize())
        self.btn_max = make_btn("▢", "", lambda *_: self.toggle_max())
        self.btn_close = make_btn("✕", "title-close", lambda *_: self.close())
        # pack_end places first-packed at the right edge; we want close rightmost,
        # so pack in reverse order: close, max, min
        for b in (self.btn_close, self.btn_max, self.btn_min):
            tb.pack_end(b, False, False, 0)

        return self._drag_handle

    # ---- focus / z-order ----
    def _on_focus(self, *_):
        if self.shell:
            self.shell.focus_window(self)

    # ---- dragging ----
    def _on_title_press(self, w, ev):
        if ev.button == 1:
            alloc = self.get_allocation()
            self._drag = (ev.x_root, ev.y_root, alloc.x, alloc.y)
        self._on_focus()

    def _on_title_motion(self, w, ev):
        if self._drag is None:
            return
        sx, sy, ox, oy = self._drag
        dx = ev.x_root - sx
        dy = ev.y_root - sy
        nx = max(0, ox + dx)
        ny = max(0, oy + dy)
        if self.shell:
            taskbar_h = self.shell.taskbar.get_allocated_height()
            ny = min(ny, SCREEN_H - taskbar_h - 40)
        if self.get_parent():
            self.get_parent().move(self._eb, nx, ny)

    def _on_title_release(self, *_):
        self._drag = None

    # ---- controls ----
    def close(self):
        if self.shell:
            self.shell.close_window(self)

    def minimize(self):
        if self.shell:
            self.shell.minimize_window(self)

    def toggle_max(self):
        if self.shell:
            self.shell.toggle_max(self)

    def set_title(self, text):
        # update label in titlebar
        for ch in self.titlebar.get_child().get_children():
            if isinstance(ch, Gtk.Label):
                ch.set_text(text)
                return


# ------------------------------------------------------------------
# Desktop icon widget
# ------------------------------------------------------------------
class DesktopIcon(Gtk.Button):
    def __init__(self, label, icon_key, on_activate):
        super().__init__()
        self.set_relief(Gtk.ReliefStyle.NONE)
        self.set_focus_on_click(True)
        self.get_style_context().add_class("desktop-icon")
        self.set_size_request(76, 82)

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        box.set_halign(Gtk.Align.CENTER)
        img = Gtk.Image.new_from_pixbuf(ICONS[icon_key].scale_simple(40, 40, GdkPixbuf.InterpType.BILINEAR))
        img.set_halign(Gtk.Align.CENTER)
        box.pack_start(img, False, False, 0)
        lbl = Gtk.Label(label=label)
        lbl.get_style_context().add_class("label")
        lbl.set_justify(Gtk.Justification.CENTER)
        lbl.set_line_wrap(True)
        lbl.set_max_width_chars(10)
        lbl.set_halign(Gtk.Align.CENTER)
        box.pack_start(lbl, False, False, 0)
        self.add(box)
        self.connect("clicked", lambda *_: on_activate())
        self.connect("button-press-event", self._on_press)

    def _on_press(self, w, ev):
        # single-click selection on desktop
        self.grab_focus()


# ------------------------------------------------------------------
# Applications
# ------------------------------------------------------------------
def build_file_explorer(shell):
    outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)

    # Toolbar
    toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=2)
    toolbar.get_style_context().add_class("explorer-toolbar")
    for sym in ("←", "→", "↑"):
        b = Gtk.Button(label=sym)
        b.set_relief(Gtk.ReliefStyle.NONE)
        b.set_focus_on_click(False)
        toolbar.pack_start(b, False, False, 0)
    addr = Gtk.Entry(text="C:\\Users\\User")
    addr.get_style_context().add_class("addressbar")
    addr.set_editable(False)
    toolbar.pack_start(addr, True, True, 2)
    outer.pack_start(toolbar, False, False, 0)

    # Body: sidebar + files
    body = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
    body.set_position(190)

    side = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
    side.get_style_context().add_class("explorer-sidebar")
    side.set_size_request(190, -1)
    quick = [("⭐ Quick access", None), ("🖥  This PC", "pc"),
             ("🖧  Network", None), ("⬇  Downloads", None),
             ("🖼  Pictures", None), ("📄  Documents", None)]
    for label, _ in quick:
        b = Gtk.RadioButton(label=label) if label.startswith("⭐") or label.startswith("🖥") else Gtk.Button(label=label)
        if isinstance(b, Gtk.RadioButton):
            b.set_mode(False)
            b.get_style_context().add_class("explorer-sidebar-btn")
        else:
            b.set_relief(Gtk.ReliefStyle.NONE)
            b.get_style_context().add_class("explorer-sidebar-btn")
        b.set_alignment(0, 0.5)
        side.pack_start(b, False, False, 0)
    side.show_all()
    body.pack1(side, False, False)

    # File grid
    files = [("Desktop", "folder"), ("Documents", "folder"),
             ("Downloads", "folder"), ("Music", "folder"),
             ("Pictures", "folder"), ("Videos", "folder"),
             ("Local Disk (C:)", "pc"), ("DVD Drive (D:)", "pc")]
    sw = Gtk.ScrolledWindow()
    sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
    grid = Gtk.FlowBox()
    grid.set_selection_mode(Gtk.SelectionMode.SINGLE)
    grid.set_min_children_per_line(4)
    grid.set_max_children_per_line(8)
    grid.set_row_spacing(8)
    grid.set_column_spacing(8)
    grid.set_border_width(12)
    for name, key in files:
        item = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        item.set_size_request(80, 80)
        img = Gtk.Image.new_from_pixbuf(ICONS[key].scale_simple(44, 44, GdkPixbuf.InterpType.BILINEAR))
        img.set_halign(Gtk.Align.CENTER)
        item.pack_start(img, False, False, 0)
        lbl = Gtk.Label(label=name)
        lbl.get_style_context().add_class("label")
        lbl.set_line_wrap(True)
        lbl.set_max_width_chars(12)
        lbl.set_halign(Gtk.Align.CENTER)
        item.pack_start(lbl, False, False, 0)
        item.show_all()
        grid.add(item)
    sw.add(grid)
    body.pack2(sw, True, False)
    outer.pack_start(body, True, True, 0)

    # Statusbar
    sb = Gtk.Label(label="8 items   |   Select an item to view details")
    sb.set_xalign(0)
    sb.get_style_context().add_class("statusbar")
    outer.pack_start(sb, False, False, 0)
    return outer


def build_notepad(shell):
    outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
    menu = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
    menu.get_style_context().add_class("menubar")
    for name in ("File", "Edit", "Format", "View", "Help"):
        b = Gtk.Button(label=name)
        b.set_relief(Gtk.ReliefStyle.NONE)
        b.get_style_context().add_class("menubar-btn")
        b.set_focus_on_click(False)
        menu.pack_start(b, False, False, 0)
    outer.pack_start(menu, False, False, 0)
    tv = Gtk.TextView()
    tv.get_style_context().add_class("notepad-view")
    tv.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
    buf = tv.get_buffer()
    buf.set_text(
        "Welcome to Notepad!\r\n\r\n"
        "This is a Windows 10-style desktop environment rendered with "
        "Python + GTK3 inside Xvfb. You can type here, open other apps "
        "from the Start menu, drag windows around, and capture "
        "screenshots or video using the helper scripts.\r\n\r\n"
        "— File  Edit  Format  View  Help —"
    )
    sw = Gtk.ScrolledWindow()
    sw.add(tv)
    outer.pack_start(sw, True, True, 0)
    sb = Gtk.Label(label="Ln 1, Col 1   |   100%   |   Windows (CRLF)   |   UTF-8")
    sb.set_xalign(0)
    sb.get_style_context().add_class("statusbar")
    outer.pack_start(sb, False, False, 0)
    return outer


def build_calculator(shell):
    outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
    outer.get_style_context().add_class("dark")
    # Header
    hdr = Gtk.Label(label="Standard")
    hdr.set_xalign(0)
    hdr.set_margin_start(12)
    hdr.set_margin_top(8)
    hdr.get_style_context().add_class("titlebar-label")
    outer.pack_start(hdr, False, False, 0)
    # Display
    display = Gtk.Label(label="0")
    display.set_xalign(1)
    display.get_style_context().add_class("calc-display")
    display.set_size_request(-1, 60)
    outer.pack_start(display, False, False, 0)

    state = {"cur": "0", "acc": None, "op": None, "reset": False}

    def render():
        display.set_text(state["cur"])

    def press(digit):
        if state["reset"] or state["cur"] == "0":
            state["cur"] = digit
            state["reset"] = False
        else:
            state["cur"] += digit
        render()

    def set_op(op):
        try:
            v = float(state["cur"])
        except ValueError:
            v = 0
        if state["acc"] is not None and state["op"] and not state["reset"]:
            compute()
        else:
            state["acc"] = v
        state["op"] = op
        state["reset"] = True

    def compute():
        if state["op"] is None or state["acc"] is None:
            return
        try:
            b = float(state["cur"])
        except ValueError:
            b = 0
        a = state["acc"]
        op = state["op"]
        r = a
        if op == "+": r = a + b
        elif op == "-": r = a - b
        elif op == "×": r = a * b
        elif op == "÷":
            r = a / b if b else 0
        if r == int(r):
            state["cur"] = str(int(r))
        else:
            state["cur"] = f"{r:g}"
        state["acc"] = None
        state["op"] = None
        state["reset"] = True
        render()

    def clear():
        state.update(cur="0", acc=None, op=None, reset=False)
        render()

    def negate():
        if state["cur"].startswith("-"):
            state["cur"] = state["cur"][1:]
        elif state["cur"] != "0":
            state["cur"] = "-" + state["cur"]
        render()

    def pct():
        try:
            v = float(state["cur"])
            state["cur"] = str(v / 100)
        except ValueError:
            pass
        render()

    grid = Gtk.Grid()
    grid.set_column_spacing(2)
    grid.set_row_spacing(2)
    grid.set_border_width(4)
    rows = [
        ["%", "CE", "C", "⌫"],
        ["⅟x", "x²", "√", "÷"],
        ["7", "8", "9", "×"],
        ["4", "5", "6", "-"],
        ["1", "2", "3", "+"],
        ["±", "0", ".", "="],
    ]
    for r, row in enumerate(rows):
        for c, sym in enumerate(row):
            b = Gtk.Button(label=sym)
            b.get_style_context().add_class("calc-btn")
            b.set_relief(Gtk.ReliefStyle.NONE)
            b.set_hexpand(True)
            b.set_vexpand(True)
            if sym in ("÷", "×", "-", "+"):
                b.get_style_context().add_class("calc-op")
            if sym == "=":
                b.get_style_context().add_class("calc-equals")
            if sym.isdigit():
                b.connect("clicked", lambda *_a, d=sym: press(d))
            elif sym == ".":
                b.connect("clicked", lambda *_: (state.update(cur=state["cur"]+".") if "." not in state["cur"] else None, render()))
            elif sym in ("+", "-", "×", "÷"):
                b.connect("clicked", lambda *_a, o=sym: set_op(o))
            elif sym == "=":
                b.connect("clicked", lambda *_: compute())
            elif sym == "C":
                b.connect("clicked", lambda *_: clear())
            elif sym == "CE":
                b.connect("clicked", lambda *_: state.update(cur="0") or render())
            elif sym == "⌫":
                b.connect("clicked", lambda *_: (state.update(cur=state["cur"][:-1] or "0"), render()))
            elif sym == "±":
                b.connect("clicked", lambda *_: negate())
            elif sym == "%":
                b.connect("clicked", lambda *_: pct())
            else:
                b.connect("clicked", lambda *_: None)
            grid.attach(b, c, r, 1, 1)
    outer.pack_start(grid, True, True, 0)
    return outer


def build_settings(shell):
    outer = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
    nav = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
    nav.get_style_context().add_class("settings-nav")
    nav.set_size_request(220, -1)
    items = ["🖥  System", "📱 Phone", "🌐 Network & Internet",
             "🎨 Personalization", "📦 Apps", "👤 Accounts",
             "🕒 Time & Language", "🎮 Gaming", "♿ Ease of Access",
             "🔒 Privacy", "🔄 Update & Security"]
    grp = None
    for i, label in enumerate(items):
        rb = Gtk.RadioButton.new_from_widget(grp) if grp else Gtk.RadioButton()
        grp = rb
        rb.set_label(label)
        rb.set_mode(False)
        rb.set_alignment(0, 0.5)
        rb.get_style_context().add_class("settings-nav-btn")
        if i == 0:
            rb.set_active(True)
        nav.pack_start(rb, False, False, 0)
    outer.pack_start(nav, False, False, 0)

    # Right pane
    right = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
    right.set_border_width(24)
    title = Gtk.Label(label="System")
    title.set_xalign(0)
    title.set_markup("<span size='xx-large' weight='bold'>System</span>")
    right.pack_start(title, False, False, 0)
    for line in [
        "🖥  Display — Monitor, brightness, night light",
        "🔊 Sound — Volume, output, input devices",
        "🔔 Notifications — Alerts from apps and system",
        "🔋 Battery — Power mode, sleep settings",
        "💾 Storage — Storage usage and sense",
        "📋 Clipboard — Clipboard history and sync",
    ]:
        b = Gtk.Button(label=line)
        b.set_relief(Gtk.ReliefStyle.NONE)
        b.set_alignment(0, 0.5)
        b.get_style_context().add_class("explorer-sidebar-btn")
        right.pack_start(b, False, False, 2)
    sw = Gtk.ScrolledWindow()
    sw.add(right)
    outer.pack_start(sw, True, True, 0)
    return outer


def build_about(shell):
    outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
    outer.set_border_width(30)
    outer.set_halign(Gtk.Align.CENTER)
    outer.set_valign(Gtk.Align.CENTER)
    logo = Gtk.Image.new_from_pixbuf(ICONS["pc"].scale_simple(96, 96, GdkPixbuf.InterpType.BILINEAR))
    logo.set_halign(Gtk.Align.CENTER)
    outer.pack_start(logo, False, False, 0)
    t = Gtk.Label()
    t.set_markup("<span size='xx-large' weight='bold'>Windows 10</span>")
    outer.pack_start(t, False, False, 0)
    s = Gtk.Label()
    s.set_markup("<span size='medium' color='#555'>GTK Edition  —  Version 22H2 (build 19045.1)</span>")
    outer.pack_start(s, False, False, 0)
    sep = Gtk.Separator()
    outer.pack_start(sep, False, False, 8)
    for k, v in [
        ("Device name", "WIN10-GTK-PC"),
        ("Processor", "PyGObject CPU @ 3.0 GHz"),
        ("Installed RAM", "4.00 GB"),
        ("System type", "64-bit operating system, x64-based processor"),
        ("Pen and touch", "No pen or touch input"),
        ("Edition", "Windows 10 Pro"),
    ]:
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        kl = Gtk.Label(label=k)
        kl.set_xalign(0)
        kl.set_halign(Gtk.Align.START)
        kl.set_size_request(160, -1)
        vl = Gtk.Label(label=v)
        vl.set_xalign(0)
        row.pack_start(kl, False, False, 0)
        row.pack_start(vl, True, True, 0)
        outer.pack_start(row, False, False, 0)
    return outer


def build_terminal(shell):
    outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
    tv = Gtk.TextView()
    tv.set_editable(False)
    tv.set_cursor_visible(False)
    tv.override_background_color(Gtk.StateFlags.NORMAL, Gdk.RGBA(0.05, 0.05, 0.08, 1))
    tv.override_color(Gtk.StateFlags.NORMAL, Gdk.RGBA(0.9, 0.9, 0.9, 1))
    tv.set_border_width(10)
    mono = Pango.FontDescription.from_string("DejaVu Sans Mono 11")
    tv.modify_font(mono)
    buf = tv.get_buffer()
    buf.set_text(
        "Microsoft Windows [Version 10.0.19045.1]\n"
        "(c) Microsoft Corporation. All rights reserved.\n\n"
        "C:\\Users\\User>python --version\n"
        "Python 3.13.5\n\n"
        "C:\\Users\\User>echo Hello from GTK!\n"
        "Hello from GTK!\n\n"
        "C:\\Users\\User>_"
    )
    sw = Gtk.ScrolledWindow()
    sw.add(tv)
    outer.pack_start(sw, True, True, 0)
    return outer


APPS = {
    "explorer": dict(title="File Explorer", icon="folder", w=780, h=520, builder=build_file_explorer),
    "notepad":  dict(title="Untitled - Notepad", icon="notepad", w=600, h=440, builder=build_notepad),
    "calc":     dict(title="Calculator", icon="calc", w=320, h=480, builder=build_calculator),
    "settings": dict(title="Settings", icon="settings", w=760, h=540, builder=build_settings),
    "about":    dict(title="About Windows", icon="pc", w=520, h=480, builder=build_about),
    "terminal": dict(title="Command Prompt", icon="terminal", w=640, h=400, builder=build_terminal),
}


# ------------------------------------------------------------------
# Start menu
# ------------------------------------------------------------------
class StartMenu(Gtk.Box):
    def __init__(self, shell):
        super().__init__(orientation=Gtk.Orientation.HORIZONTAL)
        self.shell = shell
        self.set_size_request(640, 520)
        self.get_style_context().add_class("start-menu")

        # Sidebar
        side = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        side.get_style_context().add_class("start-sidebar")
        side.set_size_request(48, -1)
        for key, handler in [
            ("user", lambda: shell.open_app("about")),
            ("folder", lambda: shell.open_app("explorer")),
            ("settings", lambda: shell.open_app("settings")),
            ("power", lambda: shell.power_menu()),
        ]:
            b = Gtk.Button()
            b.set_image(Gtk.Image.new_from_pixbuf(ICONS[key].scale_simple(20, 20, GdkPixbuf.InterpType.BILINEAR)))
            b.get_style_context().add_class("start-sidebar-btn")
            b.set_relief(Gtk.ReliefStyle.NONE)
            b.connect("clicked", lambda *_a, h=handler: self._handle(h))
            side.pack_end(b if key in ("settings", "power") else b, False, False, 0)
            # keep order roughly: spacer then items
        # simpler: pack from top
        side2 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        side2.get_style_context().add_class("start-sidebar")
        side2.set_size_request(48, -1)
        for key in ("user", "folder", "settings"):
            b = Gtk.Button()
            b.set_image(Gtk.Image.new_from_pixbuf(ICONS[key].scale_simple(20, 20, GdkPixbuf.InterpType.BILINEAR)))
            b.get_style_context().add_class("start-sidebar-btn")
            b.set_relief(Gtk.ReliefStyle.NONE)
            app = {"user": "about", "folder": "explorer", "settings": "settings"}[key]
            b.connect("clicked", lambda *_a, a=app: shell.open_app(a))
            side2.pack_start(b, False, False, 0)
        side2.pack_end(Gtk.Label(), True, True, 0)
        pb = Gtk.Button()
        pb.set_image(Gtk.Image.new_from_pixbuf(ICONS["power"].scale_simple(20, 20, GdkPixbuf.InterpType.BILINEAR)))
        pb.get_style_context().add_class("start-sidebar-btn")
        pb.set_relief(Gtk.ReliefStyle.NONE)
        pb.connect("clicked", lambda *_: shell.power_menu())
        side2.pack_end(pb, False, False, 0)
        self.pack_start(side2, False, False, 0)

        # App list
        alist = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        alist.set_size_request(280, -1)
        sec = Gtk.Label(label="P")
        sec.get_style_context().add_class("section-label")
        sec.set_xalign(0)
        alist.pack_start(sec, False, False, 0)
        app_list = [
            ("Calculator", "calc"),
            ("Command Prompt", "terminal"),
            ("File Explorer", "explorer"),
            ("Notepad", "notepad"),
            ("Settings", "settings"),
        ]
        for name, app in app_list:
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            row.set_border_width(2)
            ib = Gtk.Button()
            ib.set_image(Gtk.Image.new_from_pixbuf(ICONS[APPS[app]["icon"]].scale_simple(20, 20, GdkPixbuf.InterpType.BILINEAR)))
            ib.set_relief(Gtk.ReliefStyle.NONE)
            ib.get_style_context().add_class("start-applist-btn")
            ib.connect("clicked", lambda *_a, a=app: shell.open_app(a))
            lb = Gtk.Button(label=name)
            lb.set_relief(Gtk.ReliefStyle.NONE)
            lb.get_style_context().add_class("start-applist-btn")
            lb.set_alignment(0, 0.5)
            lb.connect("clicked", lambda *_a, a=app: shell.open_app(a))
            row.pack_start(ib, False, False, 0)
            row.pack_start(lb, True, True, 0)
            alist.pack_start(row, False, False, 0)
        alist.pack_start(Gtk.Label(), True, True, 0)
        self.pack_start(alist, False, False, 0)

        # Tiles
        tiles = Gtk.Grid()
        tiles.set_row_spacing(4)
        tiles.set_column_spacing(4)
        tiles.set_border_width(10)
        tile_defs = [
            ("Edge", "edge", "tile", 0, 0, 1, 1),
            ("Mail", "mail", "tile", 1, 0, 1, 1),
            ("Store", "store", "tile-green", 2, 0, 1, 1),
            ("Photos", "photos", "tile-red", 0, 1, 1, 1),
            ("Calendar", "settings", "tile-purple", 1, 1, 1, 1),
            ("Weather", "video", "tile-orange", 2, 1, 1, 1),
            ("Music", "music", "tile-dark", 0, 2, 2, 1),
            ("Settings", "settings", "tile", 2, 2, 1, 1),
        ]
        for name, key, cls, c, r, cw, rh in tile_defs:
            b = Gtk.Button(label=name)
            b.get_style_context().add_class("tile")
            b.get_style_context().add_class(cls)
            b.set_size_request(95 * cw, 95 * rh)
            b.set_relief(Gtk.ReliefStyle.NONE)
            app_map = {"edge": "about", "mail": "about", "store": "about",
                       "photos": "about", "video": "about", "music": "about",
                       "settings": "settings"}
            target = app_map.get(key, "about")
            b.connect("clicked", lambda *_a, a=target: shell.open_app(a))
            tiles.attach(b, c, r, cw, rh)
        self.pack_start(tiles, True, True, 0)

    def _handle(self, fn):
        fn()
        self.shell.toggle_start()


# ------------------------------------------------------------------
# Desktop shell
# ------------------------------------------------------------------
class DesktopShell(Gtk.Window):
    def __init__(self):
        super().__init__(title="Win10-DE")
        self.set_default_size(SCREEN_W, SCREEN_H)
        self.set_decorated(False)
        self.set_resizable(False)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_name("DesktopWindow")

        # Layers: wallpaper fixed, windows fixed, taskbar fixed-end, start overlay
        self.fixed = Gtk.Fixed()
        self.add(self.fixed)

        # ---- wallpaper area (icons) ----
        self.icon_layer = Gtk.Fixed()
        self.fixed.put(self.icon_layer, 0, 0)

        # desktop icons
        desk_apps = [
            ("This PC", "pc", "about"),
            ("Recycle Bin", "recycle", "about"),
            ("Documents", "folder", "explorer"),
            ("Notepad", "notepad", "notepad"),
            ("Calculator", "calc", "calc"),
            ("Terminal", "terminal", "terminal"),
        ]
        x, y = 14, 14
        for i, (name, key, app) in enumerate(desk_apps):
            di = DesktopIcon(name, key, lambda a=app: self.open_app(a))
            di.show_all()
            self.icon_layer.put(di, x, y)
            y += 86
            if y > SCREEN_H - 120:
                y = 14
                x += 90

        # ---- window layer ----
        self.win_layer = Gtk.Fixed()
        self.fixed.put(self.win_layer, 0, 0)

        # ---- taskbar ----
        self.taskbar = self._build_taskbar()
        self.fixed.put(self.taskbar, 0, SCREEN_H - 40)

        # ---- start menu (hidden) — added LAST so it paints above taskbar & windows ----
        self.start_menu = StartMenu(self)
        self.fixed.put(self.start_menu, 0, SCREEN_H - 40 - 520)
        self.start_menu.hide()  # hidden initially; toggle_start() shows it

        # ---- software cursor overlay (in-window, above every other layer) ----
        self.cursor = CursorLayer(SCREEN_W, SCREEN_H)
        self.fixed.put(self.cursor, 0, 0)
        self._cursor_visible = False

        # window state
        self.windows = []
        self.z_counter = 100
        self.minimized = {}
        self.max_state = {}
        self.task_buttons = {}
        self.start_open = False

        # clock
        self._tick_clock()
        GLib.timeout_add_seconds(1, self._tick_clock)

        # click outside start closes it
        self.add_events(Gdk.EventMask.BUTTON_PRESS_MASK)
        self.connect("button-press-event", self._on_desktop_click)

        # ---- control socket (UDP) for programmatic / video control ----
        self._init_control_socket()

        # open initial apps
        GLib.idle_add(self._boot)

    def _init_control_socket(self):
        """Listen on UDP 127.0.0.1:${WIN10_PORT} for text commands.

        Commands (one per datagram):
            open <app>        open an app (explorer|notepad|calc|settings|about|terminal)
            close <app>       close app window
            start             toggle start menu
            closeall          close all windows
            cursor x y        move the on-screen cursor to (x,y)
            cursor_show       show the software cursor
            cursor_hide       hide the software cursor
            type <text>       type text into the focused widget
            key <keysym>      press a key (e.g. Return, BackSpace, ctrl+a)
            focus <app>       bring an app's window to front
            closeall          close all windows
            quit              exit the desktop
        """
        port = int(os.environ.get("WIN10_PORT", "7890"))
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.bind(("127.0.0.1", port))
        self._sock.setblocking(False)
        GLib.io_add_watch(self._sock.fileno(), GLib.IO_IN, self._on_control)
        # Ready file so external clients can poll for startup without relying on UDP.
        ready = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".ready")
        with open(ready, "w") as f:
            f.write(f"port={port}\n")
        print(f"[win10-de] control socket listening on udp://127.0.0.1:{port}", flush=True)

    def _on_control(self, fd, cond):
        try:
            data, _ = self._sock.recvfrom(4096)
        except BlockingIOError:
            return True
        cmd = data.decode("utf-8", "replace").strip()
        print(f"[win10-de] cmd: {cmd}", flush=True)
        parts = cmd.split(None, 1)
        verb = parts[0].lower() if parts else ""
        arg = parts[1] if len(parts) > 1 else ""
        if verb == "open" and arg in APPS:
            GLib.idle_add(self.open_app, arg)
        elif verb == "close" and arg in APPS:
            for w in list(self.windows):
                if w.app_id == arg:
                    GLib.idle_add(self.close_window, w)
        elif verb == "focus" and arg in APPS:
            for w in list(self.windows):
                if w.app_id == arg:
                    GLib.idle_add(self.focus_window, w)
                    break
        elif verb == "closeall":
            for w in list(self.windows):
                GLib.idle_add(self.close_window, w)
        elif verb == "start":
            GLib.idle_add(self.toggle_start)
        elif verb == "cursor" and arg:
            try:
                sx, sy = arg.replace(",", " ").split()[:2]
                x, y = int(float(sx)), int(float(sy))
                GLib.idle_add(self._cursor_move, x, y)
            except Exception:
                pass
        elif verb == "cursor_show":
            GLib.idle_add(self._cursor_show, True)
        elif verb == "cursor_hide":
            GLib.idle_add(self._cursor_show, False)
        elif verb == "type":
            GLib.idle_add(self._type_text, arg)
        elif verb == "key":
            GLib.idle_add(self._press_key, arg)
        elif verb == "quit":
            GLib.idle_add(Gtk.main_quit)
        return True

    # ---- cursor control ----
    def _cursor_move(self, x, y):
        x = max(0, min(SCREEN_W - 1, int(x)))
        y = max(0, min(SCREEN_H - 1, int(y)))
        self.cursor.mov_co(x, y)
        return False

    def _cursor_show(self, show):
        self.cursor.show_cur(show)
        self._cursor_visible = show
        return False

    # ---- in-process keyboard synthesis ----
    def _type_text(self, text):
        """Insert text into the currently focused editable widget."""
        widget = Gtk.Window.get_focus(self) if self.get_focus() is None else self.get_focus()
        # Walk up to find an editable entry/textview
        w = widget
        while w is not None and not isinstance(w, (Gtk.Entry, Gtk.TextView, Gtk.SpinButton)):
            w = w.get_parent()
        if isinstance(w, Gtk.Entry) or isinstance(w, Gtk.SpinButton):
            w.grab_focus()
            if isinstance(w, Gtk.Entry):
                buf = w.get_buffer()
                buf.insert_at_cursor(text, -1)
            else:
                w.set_text((w.get_text() or "") + text)
        elif isinstance(w, Gtk.TextView):
            buf = w.get_buffer()
            buf.insert_at_cursor(text, -1)
        else:
            # fall back to synthesizing key events on whatever has focus
            self._send_keys(text)
        return False

    def _press_key(self, keysym_name):
        self._send_keys(keysym_name, named=True)
        return False

    def _send_keys(self, text, named=False):
        """Best-effort key synthesis via Gdk event injection.

        For plain ASCII this is fine; complex Unicode may not map to a
        keysym. `_type_text` is preferred for text (it inserts directly).
        """
        display = Gdk.Display.get_default()
        devman = display and display.get_device_manager()
        seat = display and display.get_default_seat()
        keyboard = seat.get_keyboard() if seat else None
        if named:
            keyval = Gdk.keyval_from_name(text)
            if keyval == 0:
                return
            self._emit_key(keyboard, keyval)
        else:
            for ch in text:
                kv = Gdk.unicode_to_keyval(ord(ch))
                if kv:
                    self._emit_key(keyboard, kv)

    def _emit_key(self, keyboard, keyval):
        if keyboard is None:
            return
        for press in (True, False):
            ev = Gdk.Event.new(Gdk.EventType.KEY_PRESS if press else Gdk.EventType.KEY_RELEASE)
            ev.key.window = self.get_window()
            ev.key.keyval = keyval
            ev.key.length = 0
            ev.key.state = 0
            ev.key.send_event = True
            Gtk.main_do_event(ev)
            while Gtk.events_pending():
                Gtk.main_iteration_do(False)

    def _boot(self):
        auto = os.environ.get("WIN10_AUTOOPEN", "explorer,notepad,calc")
        if auto.strip():
            for i, app in enumerate([a.strip() for a in auto.split(",") if a.strip() in APPS]):
                GLib.timeout_add(400 * (i + 1), lambda a=app: self.open_app(a))
        return False

    # ---- taskbar ----
    def _build_taskbar(self):
        tb = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        tb.set_size_request(SCREEN_W, 40)
        tb_ctx = tb.get_style_context()
        tb_ctx.add_class("taskbar")
        tb.override_background_color(Gtk.StateFlags.NORMAL, COLOR_TASKBAR_BG)

        # Start button
        self.start_btn = Gtk.ToggleButton()
        self.start_btn.set_image(Gtk.Image.new_from_pixbuf(ICONS["logo"]))
        self.start_btn.get_style_context().add_class("start-btn")
        self.start_btn.set_relief(Gtk.ReliefStyle.NONE)
        self.start_btn.set_focus_on_click(False)
        self._start_toggle_id = self.start_btn.connect("toggled", lambda *_: self.toggle_start())
        tb.pack_start(self.start_btn, False, False, 0)

        # Search box
        search = Gtk.Entry()
        search.set_placeholder_text("Type here to search")
        search.get_style_context().add_class("task-search")
        search.set_size_request(240, 30)
        search.set_valign(Gtk.Align.CENTER)
        tb.pack_start(search, False, False, 4)

        # task buttons container
        self.task_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        tb.pack_start(self.task_box, True, True, 0)

        # right tray
        tray = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        for key in ("wifi", "volume", "battery"):
            b = Gtk.Button()
            b.set_image(Gtk.Image.new_from_pixbuf(ICONS[key]))
            b.get_style_context().add_class("tray-btn")
            b.set_relief(Gtk.ReliefStyle.NONE)
            tray.pack_start(b, False, False, 0)
        # show desktop sliver
        tb.pack_end(tray, False, False, 0)

        clock = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        clock.set_valign(Gtk.Align.CENTER)
        self.clock_time = Gtk.Label(label="--:--")
        self.clock_time.get_style_context().add_class("clock-label")
        self.clock_time.set_xalign(1)
        self.clock_date = Gtk.Label(label="--/--/----")
        self.clock_date.get_style_context().add_class("clock-label")
        self.clock_date.set_xalign(1)
        clock.pack_start(self.clock_time, False, False, 0)
        clock.pack_start(self.clock_date, False, False, 0)
        tb.pack_end(clock, False, False, 4)

        # show-desktop sliver at far right
        sliver = Gtk.EventBox()
        sliver.set_size_request(4, 40)
        sliver.modify_bg(Gtk.StateFlags.NORMAL, Gdk.color_parse("rgba(0,0,0,0)"))
        tb.pack_end(sliver, False, False, 0)
        return tb

    def _tick_clock(self):
        now = datetime.datetime.now()
        self.clock_time.set_text(now.strftime("%I:%M %p").lstrip("0"))
        self.clock_date.set_text(now.strftime("%d/%m/%Y"))
        return True

    # ---- start menu ----
    def toggle_start(self):
        self.start_open = not self.start_open
        # block the button's own "toggled" handler so set_active doesn't recurse
        h = getattr(self, "_start_toggle_id", None)
        if self.start_open:
            self.start_menu.show_all()
            if h is not None:
                with self.start_btn.handler_block(h):
                    self.start_btn.set_active(True)
            else:
                self.start_btn.set_active(True)
        else:
            self.start_menu.hide()
            if h is not None:
                with self.start_btn.handler_block(h):
                    self.start_btn.set_active(False)
            else:
                self.start_btn.set_active(False)

    def power_menu(self):
        dialog = Gtk.MessageDialog(
            transient_for=self, flags=0,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK_CANCEL,
            text="Power options",
        )
        dialog.format_secondary_text("Sleep, Shut down, or Restart? (Simulated)")
        dialog.run()
        dialog.destroy()
        self.toggle_start()

    # ---- window management ----
    def open_app(self, app_key):
        if self.start_open:
            self.toggle_start()
        # if already open, just focus
        for w in self.windows:
            if w.app_id == app_key:
                if w in self.minimized:
                    del self.minimized[w]
                    w.get_eventbox().show()
                self.focus_window(w)
                return
        spec = APPS[app_key]
        content = spec["builder"](self)
        win = AppWindow(spec["title"], spec["icon"], content,
                        w=spec["w"], h=spec["h"], parent_shell=self)
        eb = win.get_eventbox()
        eb.show_all()
        # cascade
        offset = (len(self.windows) % 6) * 28
        x = 80 + offset
        y = 50 + offset
        self.win_layer.put(eb, x, y)
        self.windows.append(win)

        # taskbar button
        tb = Gtk.ToggleButton(label="  " + spec["title"].replace(" - Notepad", ""))
        tb.set_image(Gtk.Image.new_from_pixbuf(ICONS[spec["icon"]].scale_simple(16, 16, GdkPixbuf.InterpType.BILINEAR)))
        tb.set_always_show_image(True)
        tb.get_style_context().add_class("task-btn")
        tb.set_relief(Gtk.ReliefStyle.NONE)
        tb.set_focus_on_click(False)
        h_id = tb.connect("toggled", lambda *_a, w=win: self._task_btn(w))
        self.task_box.pack_start(tb, False, False, 0)
        tb.show_all()
        self.task_buttons[win] = (tb, h_id)

        self.focus_window(win)

    def _task_btn(self, win):
        tb, _h = self.task_buttons[win]
        if win in self.minimized:
            del self.minimized[win]
            win.get_eventbox().show()
            self.focus_window(win)
        else:
            active = getattr(self, "_active", None)
            if active is win:
                self.minimize_window(win)
                with tb.handler_block(_h):
                    tb.set_active(False)
            else:
                self.focus_window(win)

    def focus_window(self, win):
        self._active = win
        for w in self.windows:
            w.z = 0
        win.z = self.z_counter
        self.z_counter += 1
        # raise via X window
        eb = win.get_eventbox()
        gdkwin = eb.get_window()
        if gdkwin is not None:
            gdkwin.raise_()
        for w, (tb, h) in self.task_buttons.items():
            with tb.handler_block(h):
                tb.set_active(w is win and w not in self.minimized)

    def close_window(self, win):
        eb = win.get_eventbox()
        self.win_layer.remove(eb)
        self.windows.remove(win)
        entry = self.task_buttons.pop(win, None)
        if entry:
            tb, _h = entry
            self.task_box.remove(tb)

    def minimize_window(self, win):
        self.minimized[win] = True
        win.get_eventbox().hide()
        tb, h = self.task_buttons[win]
        with tb.handler_block(h):
            tb.set_active(False)

    def toggle_max(self, win):
        eb = win.get_eventbox()
        if win in self.max_state:
            x, y, w, h = self.max_state.pop(win)
            win.set_size_request(w, h)
            self.win_layer.move(eb, x, y)
        else:
            alloc = eb.get_allocation()
            self.max_state[win] = (alloc.x, alloc.y, win.get_allocated_width(), win.get_allocated_height())
            win.set_size_request(SCREEN_W, SCREEN_H - 40)
            self.win_layer.move(eb, 0, 0)
        self.focus_window(win)

    # ---- desktop click ----
    def _on_desktop_click(self, w, ev):
        if self.start_open:
            # close if click is not on start menu
            alloc = self.start_menu.get_allocation()
            sx, sy = self.start_menu.translate_coordinates(self, 0, 0)
            if not (sx <= ev.x <= sx + alloc.width and sy <= ev.y <= sy + alloc.height):
                self.toggle_start()


# ------------------------------------------------------------------
def main():
    load_css()
    win = DesktopShell()
    win.connect("destroy", Gtk.main_quit)
    win.show_all()
    # keep start hidden
    win.start_menu.hide()
    # Auto-show cursor on startup so recordings have a visible pointer.
    if os.environ.get("WIN10_CURSOR", "1") != "0":
        win._cursor_show(True)
    Gtk.main()


if __name__ == "__main__":
    main()
