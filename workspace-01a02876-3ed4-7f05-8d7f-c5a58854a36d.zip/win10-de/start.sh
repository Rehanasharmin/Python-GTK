#!/usr/bin/env bash
# start.sh — launch Xvfb + the Windows 10 GTK desktop.
# Thin wrapper around the CLI. For full options run: win10 start --help
set -e
cd "$(dirname "$0")"
exec ./bin/win10 start "$@"
